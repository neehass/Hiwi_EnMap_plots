library(terra)
library(plyr)
library(dplyr)
library(isopam)

# Arbeitsverzeichnis
setwd("/media/mihkel/Volume/images/EnMAP/ENMAP01-____L2A-DT0000005019_20221102T110403Z_021_V010301_20230612T153453Z")

# 1.) Fernerkundungsdaten laden und maskieren
enmap1<- rast("ENMAP01-____L2A-DT0000005019_20221102T110403Z_021_V010301_20230612T153453Z-SPECTRAL_IMAGE.TIF")
# Layerbezeichnungen umändern, da sehr lang
names(enmap1) <- paste0("b", 1:nlyr(enmap1))
enmap1
plot(subset(enmap1, c(10, 30, 50)))
clouds <- rast("ENMAP01-____L2A-DT0000005019_20221102T110403Z_021_V010301_20230612T153453Z-QL_QUALITY_CLOUD.TIF")
plot(clouds)
enmap1.masked <- mask(enmap1, clouds, maskvalues=1)
plot(subset(enmap1.masked, 10))
# Wolkenschatten
enmap2 <- subset(enmap1.masked, 1:64)
RGBsum <- sum(enmap2)
RGBsum <- app(RGBsum, function(x) ifelse(x>10000, 10000, x))
plot(RGBsum)
shadowmask <- app(RGBsum, function(x) ifelse(x < 10000, NA, x))

  # 2.) Pixelwerte extrahieren
# Dafür zunächst das shapefile mit den Mähwiesen Polygonen laden
setwd("/media/mihkel/Volume/bwsyncshare/Abschlussarbeiten/EnMAP_Maehwiesen/Daten")
mw.poly <- vect("FFH-Maehwiese/FFH-Maehwiese_polygon.shp") %>%
  crop(enmap1.masked)
plot(mw.poly)
exvals <- extract(enmap1.masked, mw.poly, exact = TRUE)
str(exvals)
colnames(exvals)
hist(exvals$fraction) 
# nur die extrahierten Werte mit fraction = 1 überlappen vollständig mit dem Polygon -> Werte < 1 rausschmeissen
# dann die Mittelwerte für jedes polygon ausrechnen, vorher NA Werte (Wolken) entfernen
exvals2 <- filter(exvals, fraction == 1, !is.na(b1)) %>%
  select(!fraction) %>% 
  group_by(ID) %>%
  summarise_all(mean)
# Anzahl an Pixeln pro Polygon (vieleicht später mal nützlich)
npix <- group_by(exvals, ID) %>%
  summarise(npix = n())
hist(npix$npix)
exvals2 <- left_join(exvals2, npix)
# so kann man sich die einzelnen Spektren schon mal anschauen, Wellenlängen fehlen aber noch
plot(1:224, exvals[10,2:225])
# Mähwiesennummer noch aus dem Shapefile Datensatz übernehmen
exvals2 <- mutate(exvals2, MW = mw.poly$MW_NUMMER[exvals2$ID])

# 3.) Zielvariablen aus dem Vegetationsdatensatz berechnen
setwd("/media/mihkel/Volume/bwsyncshare/Abschlussarbeiten/EnMAP_Maehwiesen/Daten")
# Daten laden und Mähwiesen auswählen, die mit den EnMap Daten überlappen
artinfo <- read.csv("FFH_Maehwiese.csv", sep= "\t") %>% 
  filter(MW %in% exvals2$MW)
table(artinfo$Jahr) # hier könnte man überlegen, ob man die älteren Aufnahmen weglässt
# Hier nur Daten ab 2017, für den nächsten Schritt wird Spalte Jahr dann entfernt
artinfo <- filter(artinfo, Jahr > 2016) %>%
  select(!Jahr) %>%
  mutate(presence = 1)

# Tabelle umwandeln, so dass die Information für jede Wiese in einer Spalte ist
arten <- lapply(unique(artinfo$MW), function(x){
  subs <- subset(artinfo, MW == x)
  colnames(subs) <- c("MW", "Art", subs$MW[1])
  subs[,-1]
})
arten <- join_all(arten, by = "Art", type = "full")
# alphabetisch Ordnen
arten <- arrange(arten, Art)
arten[,1:5]
arten$Art

# Die Artenlisten müssen wir noch etwas aufräumen
# Das können wir beim nächsten Treffen besprechen

# Arten als Zeilennamen und NAs mit 0 ersetzen
rownames(arten) <- arten[,1]
arten <- arten[,-1] %>%
  as.matrix()
arten[is.na(arten)] <- 0

rownames(arten) <- gsub("Urtica dioica s. str.", "Urtica dioica", rownames(arten))
rownames(arten) <- gsub("Urtica dioica s. l.", "Urtica dioica", rownames(arten))

# Beispiel KLassen mit Isopam
# für die Isopam muss die Artentabelle noch transformiert werden 
tarten <- t(arten)
ip <- isopamp(tarten[1:100,])
# hier erstmal nur mit 100 Artaufnahmen, da es sonst sehr lange rechnet
# wahrscheinlich brauchen wir dafür eine unserer Workstations
it <- isotab(ip)
it$tab

# Beispiel Ellenberg
# Liste mit Ellenberg Zeigerwerten Laden und nur die Arten aus unserem Datensatz auswählen
ellenberg <- read.csv("Ellenberg_Floraweb.csv", sep = "\t", encoding = "UTF-8") %>%
  select(TAXONNAME, Lichtzahl, Temperaturzahl, Feuchtezahl, 
         Reaktionszahl, Stickstoffzahl) %>%
  merge(data.frame(TAXONNAME = rownames(arten)), all.y = TRUE)

# Die Tabelle wird nicht vollständig sein
# fehlende Werte kannst du manuell nachtragen und die Tabelle anschließend wieder einlesen
# Das würde ich aber erst machen, wenn die Artenliste aufgeräumt ist
# write.csv(ellenberg, file = "Ellenberg_Maehwiesen.csv", row.names = FALSE)
# ellenberg <- read.csv("Ellenberg_Maehwiesen_edited.csv")

# mittlere Ellenberg Werte für jede Aufnahmefläche berechnen
# Beispielhaft für die Stickstoffzahl (für andere Zeigerwerte analog möglich)
eN <- sapply(1:nrow(arten), function(x){
  spec <- which(ellenberg$TAXONNAME == rownames(arten)[x])
  eiv <- ellenberg[spec, "Stickstoffzahl"]
  ifelse(length(eiv) == 0, NA, eiv[1])
  })
mN <- sapply(1:ncol(arten), function(x) weighted.mean(eN, arten[, x], na.rm=TRUE))
hist(mN)

output <- data.frame(MW = colnames(arten), mN = mN)
write.csv(output, ...)