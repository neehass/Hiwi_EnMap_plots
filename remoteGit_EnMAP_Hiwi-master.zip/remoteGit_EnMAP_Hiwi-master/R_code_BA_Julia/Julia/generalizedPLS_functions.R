gpls_vs <- function(df){
  
  #### Variable/model selection
  # YY <- var[1:50]
  # XX <- spectra[1:50,]
  # df <- dat
  df <- dat
  idata <- df
  bands <- list()
  errors <- numeric()
 
  for(ii in 1:50){
    if(ii > 1){
      # # select only insignificant variable coefficients (start with those with lowest values)
      # stdcoeffs <- model1$Std.Coeffs[-1, ]
      # stdcoeffs <- stdcoeffs^2
      # stdcoeffs2 <- stdcoeffs[which(names(stdcoeffs) %in% names(insigbands))]
      # stdcoeffs2 <- stdcoeffs2[order(stdcoeffs2)[1:(length(stdcoeffs)/5)]]
      # out <- which(colnames(XX) %in% gsub("X", "", names(stdcoeffs2)))
      # if(length(out)<5) out <- order(model1$Std.Coeffs[-1,])[1:length(model1$Std.Coeffs[-1])/10]
      # option 2: select insignificant bands based on their variation and absolute mean values
      coefstat <- coefstat[order(coefstat)]
      if(length(insigbands)>0) coefstat <- coefstat[which(names(coefstat) %in% names(insigbands))]
      coefstat <- coefstat[1:((ncol(df)-1)/5)]
      out <- which(colnames(df) %in% names(coefstat))
      
      df <- df[,-out]
  
    }
    cvmodel <- cv.plsRglm(resp ~ ., data = df, nt=10, K=10, modele="pls", verbose=FALSE)
    
    # optimal number of components based on AIC
    summ <- summary(cvmodel, verbose=TRUE)
    onc <- which(summ[[1]][, "AIC"] == min(summ[[1]][, "AIC"])) -1
    onc <- ifelse(onc==0, 1, onc)
    # onc = 4
    model1 <- plsR(resp ~ ., data = df, nt=10, modele="pls", verbose=FALSE)
    
    if(ii > 1){
      error1 <- error
    }
    # look at bootstapped coefficient variation -> did not proof well, try to use significance instead
    bstrp <- bootplsglm(model1, R=250)
    #bstrp <- bootpls(model1, R=250)#, typeboot="fmodel_np")
    
    coefmean <- apply(bstrp$t, 2, mean)
    names(coefmean) <- rownames(bstrp$t0)
    bstrpci <- confints.bootpls(bstrp, typeBCa=FALSE)
    # insignificant bands
    insigbands <- c(which(bstrpci[,5] < 0 & bstrpci[,6] > 0), which(bstrpci[,5] > 0 & bstrpci[,6] < 0))
    # calculate coef range
    coefran <- bstrpci[,6] - bstrpci[,5]
    # coefmean <- sqrt(apply(cbind(bstrpci[,8], bstrpci[,7]), 1, mean)^2)
    coefstat <- sqrt(coefmean^2)
    # coefstat <- coefmean/coefran
    
    # calculate error and r2  
    cvpred <- do.call(rbind, cvmodel$results_kfolds[[1]])[,(onc)]# !!!!!!!!!!!!!!! must be onc-1 if selection criterion is AIC or BIC
    cvobs <- do.call(c, cvmodel$dataY_kfolds[[1]])
    error <- sqrt((mean((cvobs-cvpred)^2)))
    r2 <- cor(cvobs, cvpred)^2
    # error <- sqrt(mean((YY-model1$FinalModel$fitted.values)^2))
    # r2 <- cor(YY, model1$FinalModel$fitted.values)^2
    print(c(ncol(df)-1, r2, error))
    bands[[ii]] <- colnames(df)[-1]
    errors[ii] <- error
    
    if((ncol(df)-1) <= 15) break
  }
  # select model with the lowest error in cv
  model.no <- which(errors==min(errors))
  # calculate models again
  bands <- idata[, colnames(idata) %in% c("resp", bands[[model.no]])]
  cvmod <- cv.plsRglm(resp ~ ., data = bands, nt=10, K=10, modele="pls", verbose=FALSE)
  summ <- summary(cvmod, verbose=FALSE)
  onc <- which(summ[[1]][, "AIC"] == min(summ[[1]][, "AIC"])) -1
  cvpred <- do.call(rbind, cvmod$results_kfolds[[1]])[,(onc)]# !!!!!!!!!!!!!!!
  cvobs <- do.call(c, cvmod$dataY_kfolds[[1]])
  #list(cvpred, cvobs, onc, bands)#
  list(c(length(nrow(df)), sqrt((mean((cvobs-cvpred)^2))), cor(cvobs, cvpred)^2, ncol(bands), onc),
       bands, df$resp)
}

# extract models, do model evaluation or get predicted values from object created in run_gpls_models.R for logistic regression
get.results <- function(model, splits, resp, preds, output=c("model", "evaluation", "prediction", "prediction.val", "prediction.all")){
  # model outputs (used predictors after variable selection) and response variables, optimal number of latent variables)
  # splits: list of plots that were used
  # resp: original response dataset
  # preds: original predictors
  # out: should the function return the model object (needed for prediction), or model evaluation infos, or predicted values (for plots)
  # model <- output[[1]]
  # splits <- splits2[[1]]
  # resp <- var
  # preds <- spectra
  
  # dataset used in the model
  XX <- model[[2]]
  YY <- model[[3]]
  onc <- model[[1]][5]
  # validataion dataset
  resp2 <- resp[-splits]
  preds2 <- spectra[-splits, colnames(preds) %in% colnames(XX)]
  # calculate model again for predictions
  fmod <- plsRglm(dataY=YY, dataX=XX, nt=onc, modele="pls-glm-logistic", verbose=FALSE)
  # predict values for evaluation
  pred1 <- predict(fmod, type="response")
  # indepenedent validation
  pred2 <- predict(object=fmod, newdata=preds2, type="response")
  pred3 <- predict(object=fmod, newdata=spectra[, colnames(preds) %in% colnames(XX)], type="response")# whole dataset
  if(output == "evaluation"){
    out <- c(sqrt((mean((YY-pred1)^2))), sqrt((mean((YY-pred1)^2))) / (max(YY)-min(YY)), cor(YY, pred1)^2,
             sqrt((mean((resp2-pred2)^2))), sqrt((mean((resp2-pred2)^2))) / (max(resp2)-min(resp2)), cor(resp2, pred2)^2,
             onc, model[[1]][4], model[[1]][1])
    names(out) <- c("rmse.cal", "rel.rsme.cal", "r2.cal", "rmse.val", "rel.rsme.val", "r2.val", "ncomp", "npred", "nsample")
    return(out)
  }
  if(output == "model") return(fmod)
  if(output == "prediction") return(pred1)
  if(output == "prediction.val") return(pred2)
  if(output == "prediction.all") return(pred3)
}

# same like above, only for log distributed data
get.results2 <- function(model, splits, resp, preds, output=c("model", "evaluation", "prediction", "prediction.val", "prediction.all")){
  # model outputs (used predictors after variable selection) and response variables, optimal number of latent variables)
  # splits: list of plots that were used
  # resp: original response dataset
  # preds: original predictors
  # out: should the function return the model object (needed for prediction), or model evaluation infos, or predicted values (for plots)
  # model <- output[[1]]
  # splits <- splits2[[1]]
  # resp <- var
  # preds <- spectra
  
  # dataset used in the model
  XX <- model[[2]]
  YY <- model[[3]]
  onc <- model[[1]][5]
  # validataion dataset
  resp2 <- resp[-splits]
  preds2 <- spectra[-splits, colnames(preds) %in% colnames(XX)]
  # calculate model again for predictions
  fmod <- plsRglm(dataY=YY, dataX=XX, nt=onc, modele="pls-glm-family", family = gaussian(link = "log"), verbose=FALSE)
  # predict values for evaluation
  pred1 <- predict(fmod, type="response") # only data used for calibration
  # indepenedent validation
  pred2 <- predict(object=fmod, newdata=preds2, type="response")
  pred3 <- predict(object=fmod, newdata=spectra[, colnames(preds) %in% colnames(XX)], type="response")# whole dataset
  if(output == "evaluation"){
    out <- c(sqrt((mean((YY-pred1)^2))), sqrt((mean((YY-pred1)^2))) / (max(YY)-min(YY)), cor(YY, pred1)^2,
             sqrt((mean((resp2-pred2)^2))), sqrt((mean((resp2-pred2)^2))) / (max(resp2)-min(resp2)), cor(resp2, pred2)^2,
             onc, model[[1]][4], model[[1]][1])
    names(out) <- c("rmse.cal", "rel.rsme.cal", "r2.cal", "rmse.val", "rel.rsme.val", "r2.val", "ncomp", "npred", "nsample")
    return(out)
  }
  if(output == "model") return(fmod)
  if(output == "prediction") return(pred1)
  if(output == "prediction.val") return(pred2)
  if(output == "prediction.all") return(pred3)
}

## Importance of variables
## - Permutation of explanatory variables, measure correlation of
##   predictions using original and randomized values (or reduction in a measure
##   of model performance)
varImp <- function(model, varnames, data, n=10) {
  # This calculation of variable importance is based on
  # the Biomod-Tutorial by Wilfried Thuiller
  varImp <- numeric(length(varnames))
  names(varImp) <- varnames
  base.pred <- predict(model, newdata=data, type="response")
  for (var in varnames) {
    varimp.test <- data
    tmp <- numeric(n)
    for (i in 1:n) {
      varimp.test[,var] <- sample(varimp.test[,var])
      tmp.pred <- predict(model, newdata=varimp.test, type="response")
      tmp[i] <- sqrt(cor(base.pred, tmp.pred, use = "complete.obs")^2)
    }
    varImp[var] <- mean(tmp, na.rm=TRUE)
  }
  data.frame(wavelength = as.numeric(gsub("X", "", names(varImp))), importance=1-varImp)
}