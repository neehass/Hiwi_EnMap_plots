# BA Satelliten und FFHWiesen #
# Auswertung EnMAP Satellitendaten von September 2023 #

# ben?tigte Pakete

library(terra)
library(plyr)
library(dplyr)
library(isopam)
library(randomForest)
library(VSURF)
library(caret) 
library(ggplot2)
library(readxl)
library(XML)
library(plotly)
library(sf)
library(gridExtra)
library(patchwork)
library(kernlab)

# MW Nummern sollen komplett angezeigt werden
options(scipen = 999)
# Standardeinstellungen: options(scipen = 0)

# Allgemeines
# Farben in R: https://r-charts.com/colors/?utm_content=cmp-true
# apropos("confusion") -> Funktionen finden

#### berechnete Tabellen ####

# exvals2: alle MW + Bänder
# noch nicht durch Jahre gefiltert
# hier sind auch noch NA Werte B?nder 131-135 + es müssen noch weitere Bänder (Wasserdampf) entfernt werden

# exvals 3: Bänder wurden entfernt 

# arten: alle Arten, die in den MW vorkommen (durch Jahre gefiltert)

# arten4: Arten wurden an Euro+Med Plantbase angepasst

# arten2: Arten wurden für Isopam angepasst

#### end ####

#### 1.) Fernerkundungsdaten laden und maskieren ####

# Daten vom 14.09.23

setwd("C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/Daten Satellit 2")
list.files()

enmap22_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105746Z_022_V010400_20231114T142140Z-SPECTRAL_IMAGE.TIF")
enmap23_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105750Z_023_V010400_20231114T142127Z-SPECTRAL_IMAGE.TIF")
enmap24_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105755Z_024_V010400_20231114T142113Z-SPECTRAL_IMAGE.TIF")
enmap25_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105759Z_025_V010400_20231114T142111Z-SPECTRAL_IMAGE.TIF")
enmap26_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105804Z_026_V010400_20231114T142111Z-SPECTRAL_IMAGE.TIF")
enmap27_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105808Z_027_V010400_20231114T142109Z-SPECTRAL_IMAGE.TIF")

cloud22_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105746Z_022_V010400_20231114T142140Z-QL_QUALITY_CLOUD.TIF")
cloud23_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105750Z_023_V010400_20231114T142127Z-QL_QUALITY_CLOUD.TIF")
cloud24_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105755Z_024_V010400_20231114T142113Z-QL_QUALITY_CLOUD.TIF")
cloud25_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105759Z_025_V010400_20231114T142111Z-QL_QUALITY_CLOUD.TIF")
cloud26_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105804Z_026_V010400_20231114T142111Z-QL_QUALITY_CLOUD.TIF")
cloud27_23 <- rast("ENMAP01-____L2A-DT0000042060_20230914T105808Z_027_V010400_20231114T142109Z-QL_QUALITY_CLOUD.TIF")

# erst einzeln maskieren
enmap22_23.masked <- mask(enmap22_23, cloud22_23, maskvalues=1)
enmap23_23.masked <- mask(enmap23_23, cloud23_23, maskvalues=1)
enmap24_23.masked <- mask(enmap24_23, cloud24_23, maskvalues=1)
enmap25_23.masked <- mask(enmap25_23, cloud25_23, maskvalues=1)
enmap26_23.masked <- mask(enmap26_23, cloud26_23, maskvalues=1)
enmap27_23.masked <- mask(enmap27_23, cloud27_23, maskvalues=1)

# zusammenfügen
enmap.masked_23 <- merge(enmap22_23.masked, enmap23_23.masked, enmap24_23.masked, enmap25_23.masked, enmap26_23.masked, enmap27_23.masked) 
plot(subset(enmap.masked_23, c(10, 30, 50))) 

# Layerbezeichnungen umändern, da sehr lang
names(enmap.masked_23) <- paste0("b", 1:nlyr(enmap.masked_23))

# Tif exportieren
# writeRaster(enmap.masked_23,'enmap.masked_23.TIF')
# in Qgis laden

# Wolkenschatten entfernen
# sichtbares Licht: 780 bis 380nm
RGB <- subset(enmap.masked_23, 1:64) # Bänder des sichtbaren Lichts
RGBsum <- sum(RGB) # Werte werden aufsummiert
plot(RGBsum)
shadowmask <- app(RGBsum, function(x) ifelse(x < 28000, NA, x)) # Schatten werden durch die niedrigsten Werte gekennzeichnet -> Schwellenwert muss gefunden werden
plot(shadowmask)

# writeRaster(shadowmask,'shadowmask23.3.TIF')
# in Qgis laden

# nochmal maskieren
enmap.masked_23.2 <- mask(enmap.masked_23, shadowmask, maskvalues=NA)
plot(subset(enmap.masked_23.2, c(10, 30, 50)))
writeRaster(enmap.masked_23.2,'enmap.masked_23.2.TIF', overwrite=TRUE)

#### end ####

#### 2.) Pixelwerte extrahieren ####
# Dafür zunächst das shapefile mit den Mähwiesen Polygonen laden
setwd("C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/Daten Maehwiesen")

# für die Daten September 2023
enmap.masked <- enmap.masked_23.2

mw.poly <- vect("FFH-Maehwiese/FFH-Maehwiese_polygon.shp") %>%
  crop(enmap.masked) # M?hwiesen werden auf Satellitenausschnitt zugeschnitten
plot(mw.poly)

exvals <- extract(enmap.masked, mw.poly, exact = TRUE) # Pixelwerte aus enmap.masked werden extrahiert, die mit Polygon ?berlappen, exact=TRUE: auch Pixel, die teilweise ?berlappen
str(exvals)
colnames(exvals)
hist(exvals$fraction) 

# nur die extrahierten Werte mit fraction = 1 überlappen vollständig mit dem Polygon -> Werte < 1 rausschmeissen
# dann die Mittelwerte für jedes polygon ausrechnen, vorher NA Werte (Wolken) entfernen
exvals2 <- filter(exvals, fraction == 1, !is.na(b1)) %>% # !: reversed, FALSE meint missing value, TRUE meint value
  select(!fraction) %>% # Spalte Fraction entfernen
  group_by(ID) %>% # Erstellung von Gruppen, damit mean berechnet werden kann
  summarise_all(mean) #Berechnung Mittelwerte der Polygone

# Anzahl an Pixeln pro Polygon
npix.poly <- group_by(exvals, ID) %>% 
  summarise(npix.poly = n())
hist(npix.poly$npix.poly)
exvals2 <- left_join(exvals2, npix.poly) %>%
  select(npix.poly, everything())

# Anzahl an verwendeten Pixeln pro Polygon
npix.used <- filter(exvals, fraction == 1, !is.na(b1)) %>% 
  select(!fraction) %>% 
  group_by(ID) %>%
  summarise(npix.used = n())
hist(npix.used$npix.used)
exvals2 <- left_join(exvals2, npix.used) %>%
  select(npix.used, everything())

# Mähwiesennummer aus dem Shapefile Datensatz übernehmen
exvals2 <- mutate(exvals2, MW = mw.poly$MW_NUMMER[exvals2$ID]) %>% 
  select(MW, everything()) %>%
  select(ID, everything())

# checken, ob MW doppelt vorkommen
length(unique(exvals2$MW)) == nrow(exvals2) # nichts doppelt

# Tabelle speichern
# write.csv(exvals2, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/exvals2_23_new.csv")

#### end ####

#### 3.) Satellitendaten bearbeiten ####
# für Wellenlängeplots siehe 13.)
# Bänder bearbeiten	
# NA Bänder entfernen
exvalsNA <- colSums(is.na(exvals2)) > 0
exvalsNA # B?nder 131-135 enthalten NA Werte
exvals3 <- exvals2[, !exvalsNA] # NA Spalten entfernen
sum(is.na(exvals3))

# von 887.729 (b78) - 1003.88 (b102) starke Intensitässchwankungen -> b79 (895.789) bis b101 (993.338) rausschneiden
exvals3 <- exvals3[, !names(exvals3) %in% paste("b", 79:101, sep = "")]
colnames(exvals3) 

# write.csv(exvals3, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/exvals3.csv")

#### end ####

#### 4.) Zielvariablen aus dem Vegetationsdatensatz berechnen ####
setwd("C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/Daten Maehwiesen")
# Daten laden und Mähwiesen auswählen, die mit den EnMap Daten überlappen
artinfo <- read.csv("FFH_Maehwiese.csv", sep= "\t") %>% 
  filter(MW %in% exvals2$MW)

# ckecken, ob MW in mehreren Jahren vorkommt
aggregate(artinfo$Jahr, list(artinfo$MW), function(x) length(unique(x))) # keine unterschiedlichen Jahre pro MW

# ?ltere Aufnahmen weglassen 
table(artinfo$Jahr) 
artinfo <- filter(artinfo, Jahr > 2018)  %>% 
  select(!Jahr) %>% mutate(presence = 1) # Jahre durch 1sen ersetzen 

# Tabelle umwandeln, so dass die Information für jede Wiese in einer Spalte ist
# lapply: erm?glicht Anwendeung einer Funktion auf Liste oder Vektor
# unique: doppelte Zeilen werden entfernt
arten <- lapply(unique(artinfo$MW), function(x){ 
  subs <- subset(artinfo, MW == x)
  colnames(subs) <- c("MW", "Art", subs$MW[1])
  subs[,-1] # Spalte wird entfernt
})
arten <- join_all(arten, by = "Art", type = "full") # Verkn?fung einer Liste von Datenrahmen
# alphabetisch Ordnen
arten <- arrange(arten, Art)

# Arten als Zeilennamen und NAs mit 0 ersetzen
rownames(arten) <- arten[,1]
arten <- arten[,-1] %>% # Spalte Arten entfernen
  as.matrix()
arten[is.na(arten)] <- 0 # NAs zu 0

# Tabelle speichern
# write.csv(arten, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/arten_23_new.csv")

#### end ####

#### 5.) Artenliste aufräumen (Arten wurden an Euro+Med Plantbase angepasst) ####
arten4 <- as.data.frame(arten)

# Notiz
# Orientierung an Euro+Med Plantbase (in Tabelle: TaxonConcept)
# keine alphabetische Reihenfolge, da es in 2 Teilen aufgeräumt wurde (nach V wieder B)

# erst die Tabelle einlesen, um zu schauen, welche Arten umbenannt werden müssen
setwd("C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/Daten Maehwiesen")
EIVE <- read_xlsx("EIVE 1.0 indicator values for niche position and niche width.xlsx", sheet = "mainTable") %>%
  select("TaxonConcept", "EIVEres-M", "EIVEres-N", "EIVEres-R", 
         "EIVEres-L", "EIVEres-T") %>%
  merge(data.frame(TaxonConcept = rownames(arten4)), all.y = TRUE)

# Spalte TaxonConcept als Zeilenname
rownames(EIVE) <- EIVE$TaxonConcept 
EIVE$TaxonConcept <- NULL

# Zeilen ausgeben lassen, die nur NA Werte enthalten
EIVE[rowSums(is.na(EIVE)) == ncol(EIVE), ]

# Achillea millefolium agg. umbenennen
row.names(arten4)[row.names(arten4) == "Achillea millefolium agg."] <- "Achillea millefolium aggr."

# Alchemilla vulgaris und Alchemilla vulgaris agg. zusammenfügen (da in EIVE nur Alchemilla vulgaris aggr.)
arten4["Alchemilla vulgaris agg.", ] <- ifelse(arten4["Alchemilla vulgaris", ] == 1 | arten4["Alchemilla vulgaris agg.", ] == 1, 1, 0)
row.names(arten4)[row.names(arten4) == "Alchemilla vulgaris agg."] <- "Alchemilla vulgaris aggr."
arten4 <- arten4[-which(rownames(arten4) == "Alchemilla vulgaris"), ]

# Anthriscus sylvestris agg. umbenennen
row.names(arten4)[row.names(arten4) == "Anthriscus sylvestris agg."] <- "Anthriscus sylvestris aggr."

# Centaurea jacea agg. umbenennen
row.names(arten4)[row.names(arten4) == "Centaurea jacea agg."] <- "Centaurea jacea aggr."

# Centaurea pannonica in Centaurea jacea subsp. angustifolia umbenennen
row.names(arten4)[row.names(arten4) == "Centaurea pannonica"] <- "Centaurea jacea subsp. angustifolia"

# Centaurea nigra subsp. nemoralis in Centaurea nemoralis umbenennen
row.names(arten4)[row.names(arten4) == "Centaurea nigra subsp. nemoralis"] <- "Centaurea nemoralis"

# Cerastium holosteoides und Cerastium holosteoides subsp. vulgare ist das gleiche -> zusammenfügen und umbenennen
arten4["Cerastium holosteoides", ] <- ifelse(arten4["Cerastium holosteoides", ] == 1 | arten4["Cerastium holosteoides subsp. vulgare", ] == 1, 1, 0) 
arten4 <- arten4[-which(rownames(arten4) == "Cerastium holosteoides subsp. vulgare"), ]
row.names(arten4)[row.names(arten4) == "Cerastium holosteoides"] <- "Cerastium fontanum subsp. vulgare"

# Crataegus monogyna agg. umbenennen
row.names(arten4)[row.names(arten4) == "Crataegus monogyna agg."] <- "Crataegus monogyna aggr."

# Draba verna agg. umbenennen
row.names(arten4)[row.names(arten4) == "Draba verna agg."] <- "Draba verna aggr."

# Erigeron acris s. l. in Erigeron acris umbennen
row.names(arten4)[row.names(arten4) == "Erigeron acris s. l."] <- "Erigeron acris"

# Festuca pratensis s. l. in Schedonorus pratensis umbenennen
row.names(arten4)[row.names(arten4) == "Festuca pratensis s. l."] <- "Schedonorus pratensis"

# Festuca ovina agg. umbenennen
row.names(arten4)[row.names(arten4) == "Festuca ovina agg."] <- "Festuca ovina aggr."

# Festuca rubra agg. umbenennen
row.names(arten4)[row.names(arten4) == "Festuca rubra agg."] <- "Festuca rubra aggr." 

# Galium mollugo agg. umbenennen
row.names(arten4)[row.names(arten4) == "Galium mollugo agg."] <- "Galium mollugo aggr." 

# Hieracium umbenennen
row.names(arten4)[row.names(arten4) == "Hieracium aurantiacum"] <- "Pilosella aurantiaca"
row.names(arten4)[row.names(arten4) == "Hieracium bauhini"] <- "Pilosella bauhini"
row.names(arten4)[row.names(arten4) == "Hieracium cymosum"] <- "Pilosella cymosa"
row.names(arten4)[row.names(arten4) == "Hieracium pilosella"] <- "Pilosella officinarum"
row.names(arten4)[row.names(arten4) == "Hieracium piloselloides"] <- "Pilosella piloselloides"
row.names(arten4)[row.names(arten4) == "Hieracium caespitosum"] <- "Pilosella caespitosa"
# Hieracium murorum bleibt 
# Hieracium maculatum bleibt 

# Hylotelephium telephium agg. umbenennen
row.names(arten4)[row.names(arten4) == "Hylotelephium telephium agg."] <- "Hylotelephium telephium aggr."

# Hypericum maculatum agg. umbenennen
row.names(arten4)[row.names(arten4) == "Hypericum maculatum agg."] <- "Hypericum maculatum aggr."

# Knautia maxima s. str. zu Knautia maxima umbenennen 
row.names(arten4)[row.names(arten4) == "Knautia maxima s. str."] <- "Knautia maxima"

# Lamium purpureum s. l. in Lamium purpureum umbenennen
row.names(arten4)[row.names(arten4) == "Lamium purpureum s. l."] <- "Lamium purpureum"

# Leucanthemum vulgare agg. umbenennen
row.names(arten4)[row.names(arten4) == "Leucanthemum vulgare agg."] <- "Leucanthemum vulgare aggr."

# Leucanthemum ircutianum subsp. ircutianum und Leucanthemum ircutianum ist das gleiche -> zusammenfügen
arten4["Leucanthemum ircutianum", ] <- ifelse(arten4["Leucanthemum ircutianum", ] == 1 | arten4["Leucanthemum ircutianum subsp. ircutianum", ] == 1, 1, 0) 
arten4 <- arten4[-which(rownames(arten4) == "Leucanthemum ircutianum subsp. ircutianum"), ]

# Lotus corniculatus agg. umbenennen
row.names(arten4)[row.names(arten4) == "Lotus corniculatus agg."] <- "Lotus corniculatus aggr."

# Medicago sativa agg. umbenennen
row.names(arten4)[row.names(arten4) == "Medicago sativa agg."] <- "Medicago sativa aggr."

# Medicago varia in Medicago ×varia umbenennen 
row.names(arten4)[row.names(arten4) == "Medicago varia"] <- "Medicago ×varia"

# Microthlaspi perfoliatum s. l. und Microthlaspi perfoliatum s. str. zusammenfügen
# und in Noccaea perfoliata umbenennn
arten4["Microthlaspi perfoliatum s. l.", ] <- ifelse(arten4["Microthlaspi perfoliatum s. l.", ] == 1 | arten4["Microthlaspi perfoliatum s. str.", ] == 1, 1, 0)
row.names(arten4)[row.names(arten4) == "Microthlaspi perfoliatum s. l."] <- "Noccaea perfoliata"
arten4 <- arten4[-which(rownames(arten4) == "Microthlaspi perfoliatum s. str."), ]

# Myosotis scorpioides und Myosotis scorpioides agg. zusammenfügen (gibt kein agg.)
arten4["Myosotis scorpioides", ] <- ifelse(arten4["Myosotis scorpioides", ] == 1 | arten4["Myosotis scorpioides agg.", ] == 1, 1, 0)
arten4 <- arten4[-which(rownames(arten4) == "Myosotis scorpioides agg."), ]

# Narcissus poeticus agg. umbenennen
row.names(arten4)[row.names(arten4) == "Narcissus poeticus agg."] <- "Narcissus poeticus aggr."

# Onobrychis viciifolia agg. umbenennen
row.names(arten4)[row.names(arten4) == "Onobrychis viciifolia agg."] <- "Onobrychis viciifolia aggr."

# Poa pratensis agg. umbenennen
row.names(arten4)[row.names(arten4) == "Poa pratensis agg."] <- "Poa pratensis aggr."

# Potentilla verna und Potentilla verna agg. zusammenfügen zu agg.
arten4["Potentilla verna", ] <- ifelse(arten4["Potentilla verna", ] == 1 | arten4["Potentilla verna agg.", ] == 1, 1, 0)
arten4 <- arten4[-which(rownames(arten4) == "Potentilla verna agg."), ]
row.names(arten4)[row.names(arten4) == "Potentilla verna"] <- "Potentilla verna aggr."

# Rosa canina agg. umbenennen
row.names(arten4)[row.names(arten4) == "Rosa canina agg."] <- "Rosa canina aggr."

# Senecio aquaticus in Jacobaea aquatica umbenennen
row.names(arten4)[row.names(arten4) == "Senecio aquaticus"] <- "Jacobaea aquatica"

# Senecio erucifolius in Jacobaea erucifolia umbenennen 
row.names(arten4)[row.names(arten4) == "Senecio erucifolius"] <- "Jacobaea erucifolia"

# Senecio jacobaea in Jacobaea vulgaris umbenennen 
row.names(arten4)[row.names(arten4) == "Senecio jacobaea"] <- "Jacobaea vulgaris"

# Silene latifolia und Silene latifolia subsp. alba -> ist das gleiche, zusammenfügen
arten4["Silene latifolia", ] <- ifelse(arten4["Silene latifolia", ] == 1 | arten4["Silene latifolia subsp. alba", ] == 1, 1, 0)
arten4 <- arten4[-which(rownames(arten4) == "Silene latifolia subsp. alba"), ]

# Tragopogon pratensis s. l. und Tragopogon pratensis s. str. zu Tragopogon pratensis zusammenfügen
arten4["Tragopogon pratensis s. l.", ] <- ifelse(arten4["Tragopogon pratensis s. l.", ] == 1 | arten4["Tragopogon pratensis s. str.", ] == 1, 1, 0)
row.names(arten4)[row.names(arten4) == "Tragopogon pratensis s. l."] <- "Tragopogon pratensis"
arten4 <- arten4[-which(rownames(arten4) == "Tragopogon pratensis s. str."), ]

# Urtica dioica s. l. und Urtica dioica s. str. zu Urtica dioica zusammenfügen
arten4["Urtica dioica s. l.", ] <- ifelse(arten4["Urtica dioica s. l.", ] == 1 | arten4["Urtica dioica s. str.", ] == 1, 1, 0)
row.names(arten4)[row.names(arten4) == "Urtica dioica s. l."] <- "Urtica dioica"
arten4 <- arten4[-which(rownames(arten4) == "Urtica dioica s. str."), ]

# Vicia angustifolia s. l. und Vicia angustifolia s. str. zusammenfügen
# und in Vicia sativa subsp. nigra umbenennen
arten4["Vicia angustifolia s. l.", ] <- ifelse(arten4["Vicia angustifolia s. l.", ] == 1 | arten4["Vicia angustifolia s. str.", ] == 1, 1, 0)
row.names(arten4)[row.names(arten4) == "Vicia angustifolia s. l."] <- "Vicia sativa subsp. nigra"
arten4 <- arten4[-which(rownames(arten4) == "Vicia angustifolia s. str."), ]

# Vicia segetalis zu Vicia sativa subsp. nigra hinzufügen (ist das gleiche)
arten4["Vicia sativa subsp. nigra", ] <- ifelse(arten4["Vicia sativa subsp. nigra", ] == 1 | arten4["Vicia segetalis", ] == 1, 1, 0)
arten4 <- arten4[-which(rownames(arten4) == "Vicia segetalis"), ]

# Vicia cracca agg. umbenennen
row.names(arten4)[row.names(arten4) == "Vicia cracca agg."] <- "Vicia cracca aggr."

# Vicia sativa und Vicia sativa agg. zusammenfügen (gibt kein agg.)
arten4["Vicia sativa", ] <- ifelse(arten4["Vicia sativa agg.", ] == 1 | arten4["Vicia sativa", ] == 1, 1, 0)
arten4 <- arten4[-which(rownames(arten4) == "Vicia sativa agg."), ]

# Vitis vinifera s. l. und Vitis vinifera s. str. zu Vitis vinifera zusammenfügen
arten4["Vitis vinifera s. l.", ] <- ifelse(arten4["Vitis vinifera s. l.", ] == 1 | arten4["Vitis vinifera s. str.", ] == 1, 1, 0)
row.names(arten4)[row.names(arten4) == "Vitis vinifera s. l."] <- "Vitis vinifera"
arten4 <- arten4[-which(rownames(arten4) == "Vitis vinifera s. str."), ]

# Betonica officinalis in Stachys officinalis umbenennen
row.names(arten4)[row.names(arten4) == "Betonica officinalis"] <- "Stachys officinalis"

# Bromus erectus in Bromopsis erecta umbenennen
row.names(arten4)[row.names(arten4) == "Bromus erectus"] <- "Bromopsis erecta"

# Bromus inermis in Bromopsis inermis umbenennen
row.names(arten4)[row.names(arten4) == "Bromus inermis"] <- "Bromopsis inermis"

# Bromus sterilis in Anisantha sterilis umbenennen
row.names(arten4)[row.names(arten4) == "Bromus sterilis"] <- "Anisantha sterilis"

# Carex muricata agg. in Carex muricata aggr. umbenennen
row.names(arten4)[row.names(arten4) == "Carex muricata agg."] <- "Carex muricata aggr."

# Carex otrubae in Carex cuprina umbenennen
row.names(arten4)[row.names(arten4) == "Carex otrubae"] <- "Carex cuprina"

# Cerastium glutinosum in Cerastium pumilum subsp. glutinosum umbenennen
row.names(arten4)[row.names(arten4) == "Cerastium glutinosum"] <- "Cerastium pumilum subsp. glutinosum"

# Draba muralis in Drabella muralis umbenennen
row.names(arten4)[row.names(arten4) == "Draba muralis"] <- "Drabella muralis"

# Elymus repens in Elytrigia repens umbenennen
row.names(arten4)[row.names(arten4) == "Elymus repens"] <- "Elytrigia repens"

# Festuca arundinacea in Schedonorus arundinaceus umbenennen
row.names(arten4)[row.names(arten4) == "Festuca arundinacea"] <- "Schedonorus arundinaceus"

# Gentianopsis ciliata in Gentianella ciliata umbenennen
row.names(arten4)[row.names(arten4) == "Gentianopsis ciliata"] <- "Gentianella ciliata"

# Helictotrichon pratense in Helictochloa pratensis
row.names(arten4)[row.names(arten4) == "Helictotrichon pratense"] <- "Helictochloa pratensis"

# Helictotrichon pubescens in Avenula pubescens umbenennen
row.names(arten4)[row.names(arten4) == "Helictotrichon pubescens"] <- "Avenula pubescens"

# Iris germanica in Iris ×germanica umbenennen
row.names(arten4)[row.names(arten4) == "Iris germanica"] <- "Iris ×germanica"

# Listera ovata in Neottia ovata umbenennen
row.names(arten4)[row.names(arten4) == "Listera ovata"] <- "Neottia ovata"

# Lychnis flos-cuculi in Silene flos-cuculi
row.names(arten4)[row.names(arten4) == "Lychnis flos-cuculi"] <- "Silene flos-cuculi"

# Malus domestica in Malus pumila
row.names(arten4)[row.names(arten4) == "Malus domestica"] <- "Malus pumila"

# Ononis repens in Ononis spinosa subsp. procurrens
row.names(arten4)[row.names(arten4) == "Ononis repens"] <- "Ononis spinosa subsp. procurrens"

# Orchis pyramidalis in Anacamptis pyramidalis umbenennen
row.names(arten4)[row.names(arten4) == "Orchis pyramidalis"] <- "Anacamptis pyramidalis"

# Potentilla anserina in Argentina anserina umbenennen
row.names(arten4)[row.names(arten4) == "Potentilla anserina"] <- "Argentina anserina"

# Ranunculus auricomus agg. in Ranunculus auricomus aggr.
row.names(arten4)[row.names(arten4) == "Ranunculus auricomus agg."] <- "Ranunculus auricomus aggr."

# Rubus sectio Rubus in Rubus sect. Rubus
row.names(arten4)[row.names(arten4) == "Rubus sectio Rubus"] <- "Rubus sect. Rubus"

# Taraxacum sectio Ruderalia in Taraxacum sect. Taraxacum umbenennen
row.names(arten4)[row.names(arten4) == "Taraxacum sectio Ruderalia"] <- "Taraxacum sect. Taraxacum"

# Tragopogon orientalis in Tragopogon pratensis subsp. orientalis
row.names(arten4)[row.names(arten4) == "Tragopogon orientalis"] <- "Tragopogon pratensis subsp. orientalis"

# Valeriana officinalis agg. in Valeriana officinalis aggr.
row.names(arten4)[row.names(arten4) == "Valeriana officinalis agg."] <- "Valeriana officinalis aggr."

# Veronica teucrium in Veronica austriaca subsp. teucrium
row.names(arten4)[row.names(arten4) == "Veronica teucrium"] <- "Veronica austriaca subsp. teucrium"

# Viola canina agg. in Viola canina umbenennen
row.names(arten4)[row.names(arten4) == "Viola canina agg."] <- "Viola canina"

# schauen ob es geklappt hat
EIVE <- read_xlsx("EIVE 1.0 indicator values for niche position and niche width.xlsx", sheet = "mainTable") %>%
  select("TaxonConcept", "EIVEres-M", "EIVEres-N", "EIVEres-R", 
         "EIVEres-L", "EIVEres-T") %>%
  merge(data.frame(TaxonConcept = rownames(arten4)), all.y = TRUE)

rownames(EIVE) <- EIVE$TaxonConcept 
EIVE$TaxonConcept <- NULL

# Zeilen ausgeben lassen, die nur NA Werte enthalten
EIVE[rowSums(is.na(EIVE)) == ncol(EIVE), ]

# für diese Arten gibt es keine Werte bzw. es konnten keine Synonyme gefunden werden
# Achillea biebersteinii 
# Rumex obovatus
# Euphrasia officinalis subsp. pratensis: gibt im Rothmaler mehrere Synonyme, welche dann in EIVE gefunden werden, allerdings keine eindeutige Zuordnung möglich -> Name wurde gelassen

# alphabetisch Ordnen
arten4 <- arrange(arten4, rownames(arten4))

# write.csv(arten4, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/arten.EIVE.csv")

#### end ####

#### 6.) Artenliste für Isopam aufräumen #### 
# Arten werden zu aggr zusammengefügt
arten2 <- arten4

# Achillea millefolium aggr. schließt Achillea millefolium ein
arten2["Achillea millefolium aggr.", ] <- ifelse(arten2["Achillea millefolium aggr.", ] == 1 | arten2["Achillea millefolium", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Achillea millefolium"), ]

# Anthriscus sylvestris, Anthriscus sylvestris aggr., Anthriscus sylvestris subsp. sylvestris
arten2["Anthriscus sylvestris aggr.", ] <- ifelse(arten2["Anthriscus sylvestris aggr.", ] == 1 | arten2["Anthriscus sylvestris", ] == 1 | arten2["Anthriscus sylvestris subsp. sylvestris", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Anthriscus sylvestris"), ]
arten2 <- arten2[-which(rownames(arten2) == "Anthriscus sylvestris subsp. sylvestris"), ]

# Centaurea jacea, Centaurea jacea aggr., Centaurea jacea subsp. angustifolia
arten2["Centaurea jacea aggr.", ] <- ifelse(arten2["Centaurea jacea aggr.", ] == 1 | arten2["Centaurea jacea", ] == 1 | arten2["Centaurea jacea subsp. angustifolia", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Centaurea jacea"), ]
arten2 <- arten2[-which(rownames(arten2) == "Centaurea jacea subsp. angustifolia"), ]

# Crataegus monogyna aggr., Crataegus monogyna
arten2["Crataegus monogyna aggr.", ] <- ifelse(arten2["Crataegus monogyna", ] == 1 | arten2["Crataegus monogyna aggr.", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Crataegus monogyna"), ]

# Draba verna, Draba verna aggr.
arten2["Draba verna aggr.", ] <- ifelse(arten2["Draba verna aggr.", ] == 1 | arten2["Draba verna", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Draba verna"), ]

# Festuca ovina, Festuca ovina aggr.
arten2["Festuca ovina aggr.", ] <- ifelse(arten2["Festuca ovina aggr.", ] == 1 | arten2["Festuca ovina", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Festuca ovina"), ]

# Festuca rubra, Festuca rubra aggr.
arten2["Festuca rubra aggr.", ] <- ifelse(arten2["Festuca rubra aggr.", ] == 1 | arten2["Festuca rubra", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Festuca rubra"), ]

# Galium mollugo aggr. schließt Galium album und Galium mollugo mit ein
arten2["Galium mollugo aggr.", ] <- ifelse(arten2["Galium mollugo aggr.", ] == 1 | arten2["Galium album", ] == 1 | arten2["Galium mollugo", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Galium album"), ]
arten2 <- arten2[-which(rownames(arten2) == "Galium mollugo"), ]

# Hypericum maculatum aggr. schließt Hypericum maculatum mit ein
arten2["Hypericum maculatum aggr.", ] <- ifelse(arten2["Hypericum maculatum aggr.", ] == 1 | arten2["Hypericum maculatum", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Hypericum maculatum"), ]

# Leucanthemum vulgare aggr. schließt Leucanthemum ircutianum,  Leucanthemum vulgare
arten2["Leucanthemum vulgare aggr.", ] <- ifelse(arten2["Leucanthemum vulgare aggr.", ] == 1 | arten2["Leucanthemum ircutianum", ] == 1 | arten2["Leucanthemum vulgare", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Leucanthemum ircutianum"), ]
arten2 <- arten2[-which(rownames(arten2) == "Leucanthemum vulgare"), ]

# Lotus corniculatus aggr. schließt Lotus corniculatus mit ein
arten2["Lotus corniculatus aggr.", ] <- ifelse(arten2["Lotus corniculatus aggr.", ] == 1 | arten2["Lotus corniculatus", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Lotus corniculatus"), ]

# Medicago sativa und Medicago sativa aggr. zu Medicago ×varia zusammenfügen
arten2["Medicago ×varia", ] <- ifelse(arten2["Medicago ×varia", ] == 1 | arten2["Medicago sativa", ] == 1 | arten2["Medicago sativa aggr.", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Medicago sativa"), ]
arten2 <- arten2[-which(rownames(arten2) == "Medicago sativa aggr."), ]

# Onobrychis viciifolia aggr. und Onobrychis viciifolia
arten2["Onobrychis viciifolia aggr.", ] <- ifelse(arten2["Onobrychis viciifolia aggr.", ] == 1 | arten2["Onobrychis viciifolia", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Onobrychis viciifolia"), ]

# Origanum vulgare und Origanum vulgare subsp. vulgare
arten2["Origanum vulgare", ] <- ifelse(arten2["Origanum vulgare", ] == 1 | arten2["Origanum vulgare subsp. vulgare", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Origanum vulgare subsp. vulgare"), ]

# Picris hieracioides und Picris hieracioides subsp. hieracioides
arten2["Picris hieracioides", ] <- ifelse(arten2["Picris hieracioides", ] == 1 | arten2["Picris hieracioides subsp. hieracioides", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Picris hieracioides subsp. hieracioides"), ]

# Poa pratensis aggr. schließt Poa pratensis und Poa angustifolia
arten2["Poa pratensis aggr.", ] <- ifelse(arten2["Poa pratensis aggr.", ] == 1 | arten2["Poa pratensis", ] == 1 | arten2["Poa angustifolia", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Poa pratensis"), ]
arten2 <- arten2[-which(rownames(arten2) == "Poa angustifolia"), ]

# Polygala vulgaris, Polygala vulgaris subsp. vulgaris
arten2["Polygala vulgaris", ] <- ifelse(arten2["Polygala vulgaris", ] == 1 | arten2["Polygala vulgaris subsp. vulgaris", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Polygala vulgaris subsp. vulgaris"), ]

# Rosa canina, Rosa canina aggr.
arten2["Rosa canina aggr.", ] <- ifelse(arten2["Rosa canina aggr.", ] == 1 | arten2["Rosa canina", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Rosa canina"), ]

# Silene vulgaris subsp. vulgaris und Silene vulgaris
arten2["Silene vulgaris", ] <- ifelse(arten2["Silene vulgaris", ] == 1 | arten2["Silene vulgaris subsp. vulgaris", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Silene vulgaris subsp. vulgaris"), ]

# Tragopogon pratensis, Tragopogon pratensis subsp. orientalis
arten2["Tragopogon pratensis", ] <- ifelse(arten2["Tragopogon pratensis", ] == 1 | arten2["Tragopogon pratensis subsp. orientalis", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Tragopogon pratensis subsp. orientalis"), ]

# Vicia cracca aggr. schließt Vicia cracca mit ein
arten2["Vicia cracca aggr.", ] <- ifelse(arten2["Vicia cracca aggr.", ] == 1 | arten2["Vicia cracca", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Vicia cracca"), ]

# Vicia sativa, Vicia sativa subsp. nigra
arten2["Vicia sativa", ] <- ifelse(arten2["Vicia sativa", ] == 1 | arten2["Vicia sativa subsp. nigra", ] == 1, 1, 0)
arten2 <- arten2[-which(rownames(arten2) == "Vicia sativa subsp. nigra"), ]

# auf NA Werte prüfen
any(is.na(arten2)) # passt

# write.csv(arten2, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/arten.Iso.csv")

#### end ####

#### 7.) Klassifikation mit Isopam (un?berwacht) ####
arten2 <- as.matrix(arten2)
tarten2 <- t(arten2) # Tabelle transformieren (Tauschen von Zeilen und Spalten)

### Isopam Klassifikation 5 Klassen 
set.seed(2454876)
# entscheidet sich mit Standardeinstellung für 5 Klassen
ip <- isopam(tarten2) 
plot(ip)
# Infos

it <- isotab(ip)
it

# Zahl: Bsp.: in 90% der MW von Gruppe 1 Centaurea jacea 
# Sternchen: wie signifikant -> je mehr Sternchen desto besser, aber problematisch wenn in beiden Gruppen signifikant?

# anzeigen, welche MW zu welcher Klasse zugeordnet wurden
classes <- ip$flat$lev.1
classes

classes.dataframe <- as.data.frame(classes)
classes.dataframe <- cbind(rownames(classes.dataframe), data.frame(classes.dataframe, row.names=NULL))
colnames(classes.dataframe)[1] <- "MW"

# Klassen umbenennen
classes.dataframe$classes[which(classes.dataframe$classes == 1)] <- 'Klasse 1'
classes.dataframe$classes[which(classes.dataframe$classes == 2)] <- 'Klasse 2'
classes.dataframe$classes[which(classes.dataframe$classes == 3)] <- 'Klasse 3'
classes.dataframe$classes[which(classes.dataframe$classes == 4)] <- 'Klasse 4'
classes.dataframe$classes[which(classes.dataframe$classes == 5)] <- 'Klasse 5'
classes.dataframe$classes <- as.factor(classes.dataframe$classes) # classes als Faktor

# classes.dataframe <- write.csv(classes.dataframe, "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/classes.dataframe.csv")

### Isopam Klassifikation mit 4 Klassen (ist Minimum) 
set.seed(548739)
ip4 <- isopam(tarten2, k = 4) 

it4 <- isotab(ip4)
it4

# write.csv(it4$tab, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/it4.csv")

# anzeigen, welche MW zu welcher Klasse zugeordnet wurden
classes4 <- ip4$flat$lev.1
classes4

classes4.dataframe <- as.data.frame(classes4) %>%
  rename(classes = classes4)
classes4.dataframe <- cbind(rownames(classes4.dataframe), data.frame(classes4.dataframe, row.names=NULL))
colnames(classes4.dataframe)[1] <- "MW"

# Klassen umbenennen
classes4.dataframe$classes[which(classes4.dataframe$classes == 1)] <- 'Klasse 1'
classes4.dataframe$classes[which(classes4.dataframe$classes == 2)] <- 'Klasse 2'
classes4.dataframe$classes[which(classes4.dataframe$classes == 3)] <- 'Klasse 3'
classes4.dataframe$classes[which(classes4.dataframe$classes == 4)] <- 'Klasse 4'
classes4.dataframe$classes <- as.factor(classes4.dataframe$classes) # classes als Faktor

# Schauen wie groß Klassen sind
sum(classes4.dataframe$classes == "Klasse 1")
sum(classes4.dataframe$classes == "Klasse 2")
sum(classes4.dataframe$classes == "Klasse 3")
sum(classes4.dataframe$classes == "Klasse 4")

# write.csv(classes4.dataframe, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/classes4.dataframe.csv")

#### end ####

#### 8.) Ordination ####
# NMDS
# Stresswerte anschauen, Stress > 0.2 nicht so gut 
# https://github.com/vegandevs/vegan/issues/413
set.seed(64758)
nmds3 <- metaMDS(tarten2, k=3, trymax = 40, sfgrmin = 1e-12, previous.best = nmds3) # Anzahl Dimensionen erhöhen -> Best solution soll repeated werden (stabile Lösung)
nmds3

# 3D Plot 
# https://plotly.com/r/3d-scatter-plots/
# Ins richtige Format bringen
# für 5 Klassen
str(nmds3)
nmds3.points <- nmds3$points %>%
  as_tibble(rownames="MW")
nmds3.points <- merge(nmds3.points, classes.dataframe, by = "MW") # classes hinzufügen

# Plot erstellen
nmds3_plot <- plot_ly(nmds3.points, x = ~MDS1, y = ~MDS2, z = ~MDS3, color = ~classes, colors = c('#76EEC6', '#CD2626', '#EEEE00', '#E9967A', "black"),
                      marker = list (size = 5), # hier
                      text = ~paste('MW:', MW, 'Klasse:', classes)) # und hier kommt Meldung, funktioniert aber trotzdem
# nmds3_plot <- nmds3_plot %>% add_markers(marker = list (size = 5)) # hier keine Meldung
nmds3_plot <- nmds3_plot %>% layout(title = "NMDS", 
                                    scene = list(xaxis = list(title = 'NMDS1'),
                                    yaxis = list(title = 'NMDS2'),
                                    zaxis = list(title = 'NMDS3')))
nmds3_plot

# für 4 Klassen
str(nmds3)
nmds3.points4 <- nmds3$points %>%
  as_tibble(rownames="MW")
nmds3.points4 <- merge(nmds3.points4, classes4.dataframe, by = "MW") # classes hinzufügen

# Plot erstellen
nmds3_plot4 <- plot_ly(nmds3.points4, x = ~MDS1, y = ~MDS2, z = ~MDS3, color = ~classes, colors = c('#4A708B', '#43CD80', '#EE8262', '#CDB5CD'),
                      marker = list (size = 5), # hier
                      text = ~paste('MW:', MW, 'Klasse:', classes)) # und hier kommt Meldung, funktioniert aber trotzdem
# nmds3_plot <- nmds3_plot %>% add_markers(marker = list (size = 5)) # hier keine Meldung
nmds3_plot4 <- nmds3_plot4 %>% layout(title = "NMDS", 
                                    scene = list(xaxis = list(title = 'MDS1'),
                                                 yaxis = list(title = 'MDS2'),
                                                 zaxis = list(title = 'MDS3')))
nmds3_plot4

#### end ####

#### 9.) mittlere Harmonisierte Indikatorwerte für Europa berechnen (pro Wiese) ####

# Soil moisture (M) (Feuchte)
EIVE_M <- sapply(1:nrow(arten4), function(x){ 
  spec <- which(rownames(EIVE) == rownames(arten4)[x])
  eiv <- EIVE[spec, "EIVEres-M"]
  ifelse(length(eiv) == 0, NA, eiv[1])
})
mM <- sapply(1:ncol(arten4), function(x) weighted.mean(EIVE_M, arten4[, x], na.rm=TRUE))
hist(mM)

# Soil nitrogen (N) (Stickstoff) 
EIVE_N <- sapply(1:nrow(arten4), function(x){ 
  spec <- which(rownames(EIVE) == rownames(arten4)[x])
  eiv <- EIVE[spec, "EIVEres-N"]
  ifelse(length(eiv) == 0, NA, eiv[1])
})
mN <- sapply(1:ncol(arten4), function(x) weighted.mean(EIVE_N, arten4[, x], na.rm=TRUE))
hist(mN)

# Soil reaction (R) (entspricht Reaktionszahl?)
EIVE_R <- sapply(1:nrow(arten4), function(x){ 
  spec <- which(rownames(EIVE) == rownames(arten4)[x])
  eiv <- EIVE[spec, "EIVEres-R"]
  ifelse(length(eiv) == 0, NA, eiv[1])
})
mR <- sapply(1:ncol(arten4), function(x) weighted.mean(EIVE_R, arten4[, x], na.rm=TRUE))
hist(mR)

# Light (L) (Licht)
EIVE_L <- sapply(1:nrow(arten4), function(x){ 
  spec <- which(rownames(EIVE) == rownames(arten4)[x])
  eiv <- EIVE[spec, "EIVEres-L"]
  ifelse(length(eiv) == 0, NA, eiv[1])
})
mL <- sapply(1:ncol(arten4), function(x) weighted.mean(EIVE_L, arten4[, x], na.rm=TRUE))
hist(mL)

# Temperature (T) (Temperatur)
EIVE_T <- sapply(1:nrow(arten4), function(x){ 
  spec <- which(rownames(EIVE) == rownames(arten4)[x])
  eiv <- EIVE[spec, "EIVEres-T"]
  ifelse(length(eiv) == 0, NA, eiv[1])
})
mT <- sapply(1:ncol(arten4), function(x) weighted.mean(EIVE_T, arten4[, x], na.rm=TRUE))
hist(mT)

# zu einem Dataframe zusammenfügen
EIVE_mean <- data.frame(MW = colnames(arten4), mN = mN, mM = mM, mR = mR, mL = mL, mT = mT)

# write.csv(EIVE_mean, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/EIVE_mean.csv")

#### end ####

#### 10.) mittlere Indikatorwerte für jede Klasse berechnen ####
# für 5 Klassen
classes_mean <- merge.data.frame(classes.dataframe, EIVE_mean, by = "MW")

classes_mean <- classes_mean %>%
  group_by(classes) %>%
  summarise(
    mean_mN = mean(mN),
    mean_mM = mean(mM),
    mean_mR = mean(mR)
  )

# für 4 Klassen
classes4_mean <- merge.data.frame(classes4.dataframe, EIVE_mean, by = "MW")

classes4_mean <- classes4_mean %>%
  group_by(classes) %>%
  summarise(
    mean_mN = mean(mN),
    mean_mM = mean(mM),
    mean_mR = mean(mR)
  )

# vlt Boxplots?

#### end ####

#### 11.) Random Forest Modell Harmonisierte Indikatorwerte ####
# Tutorials: 
# https://topepo.github.io/caret/index.html
# https://koalatea.io/r-random-forest-regression/
# https://minimatech.org/linear-regression-with-r-and-caret/
# predictor: Bänder (sind 196)
# response: Indikatorwerte
# für Regression: mtry = floor(ncol(train_mN)/3)

# Erklärungen random forest
# Kreuzvaliduerng (cv): number: wird in 10 Gruppen unterteilt (k), jeweils 10% werden zurückgehalten (anhand der restlichen Daten wird Modell gebildet)
# mtry: Anzahl an getesteten Variablen pro Knoten
# tuneLength: wie oft verschiedene Anzahl an Variablen an einem Knoten getestet werden soll (Standard sind mtry = 3)
# ntree: Anzahl der Bäume
# metric: Parameter, nach welchem Modell ausgewählt wird (zB Accuracy oder ROC)

### Modell mN ###

# Datensatz mN erstellen
# nur die MW,  die auch für Indikatorwert verwendet wurden herausfiltern
rf.EIVE_mN <- merge(exvals3, EIVE_mean, by = "MW") %>% 
  select(-mM, -mR, -mL, -mT) 
rf.EIVE_mN <- rf.EIVE_mN[,5:201] # nur Bänder und Indikatorwert verwenden

# Datensatz aufteilen (stratifizierte Zufallsstichprobe)
set.seed(2647)
trainIndex_mN <- createDataPartition(rf.EIVE_mN$mN, p = .80, list = FALSE) # caret
train_mN <- rf.EIVE_mN[trainIndex_mN,]
test_mN  <- rf.EIVE_mN[-trainIndex_mN,]

# Variablenauswahl mit VSURF
# ntree standardmäßig 2000
# mtry standardmäßig floor(ncol(train_mN)/3)
VSURF_mN <- VSURF(x = train_mN[,1:196], y = train_mN$mN)
VSURF_mN
# AusgewÃ¤hlte Variablen
VSURF_mN$varselect.pred
colnames(train_mN)[VSURF_mN$varselect.pred] # Spaltennamen
train_mN.vsurf <- train_mN[,colnames(train_mN)[VSURF_mN$varselect.pred]] # neuen Dataframe mit ausgewählten Spalten erzeugen
train_mN.vsurf$mN <- train_mN$mN # Spalte mN hinzufügen
# 11 Bänder
# "b115" "b116" "b130" "b54"  "b114" "b25"  "b129" "b55"  "b224" "b139" "b112"

# rf modell mit ausgewähten Variablen
ctrl <- trainControl(method = 'cv', number = 10) # Kreuzvalidierung
tuneGrid <- expand.grid(.mtry = c(3,4)) # mtry festlegen
set.seed(13674) 
model.mN <- train(mN ~ ., 
                data = train_mN.vsurf, 
                method = 'rf', 
                trControl = ctrl, 
                tuneGrid = tuneGrid, 
                ntree = 1000) 
model.mN
model.mN$finalModel

# nrmse training
nrmse.train.N <- 0.3220425 / (max(train_mN$mN) - min(train_mN$mN)) * 100

# aus caret package, scale = FALSE verhindert normieren
# Variable importance plot
varimp.mN <- varImp(model.mN)  

importance.mN <- ggplot(varimp.mN) +
  ggtitle("model.mN")

# Modell auf Testdaten anwenden
predict.mN <- predict(model.mN, newdata = test_mN) # stats

# Modellgüte berechnen
mN.values <- postResample(pred = predict.mN, obs = test_mN$mN) # caret
nrmse.test.N <- mN.values[1] / (max(test_mN$mN) - min(test_mN$mN)) * 100

# predicted vs. observed
plot_mN <- ggplot(mapping = aes(x = predict.mN, y = test_mN$mN)) +
  geom_point() +
  xlim(range(test_mN$mN)) +
  ylim(range(test_mN$mN)) +
  ggtitle("Stickstoff (N)") +
  xlab("Vorhersage") +
  ylab("Beobachtung") +
  geom_abline(color = "grey", linetype = 2) +
  annotate("text", x = Inf, y = -Inf, label = paste("R² =", round(mN.values[2], 3)),
           hjust = 1.18, vjust = -3.5) +
  annotate("text", x = Inf, y = -Inf, label = paste("RMSE =", round(mN.values[1], 3)),
           hjust = 1.127, vjust = -1.5) +
  theme_bw()
plot_mN

### Modell mM ###

# Datensatz mM erstellen
# nur die MW,  die auch für Indikatorwert verwendet wurden herausfiltern
rf.EIVE_mM <- merge(exvals3, EIVE_mean, by = "MW") %>% 
  select(-mN, -mR, -mL, -mT) 
rf.EIVE_mM <- rf.EIVE_mM[,5:201] # nur Bänder und Indikatorwert verwenden

# Datensatz aufteilen
set.seed(26477)
trainIndex_mM <- createDataPartition(rf.EIVE_mM$mM, p = .80, list = FALSE)
train_mM <- rf.EIVE_mM[trainIndex_mM,]
test_mM  <- rf.EIVE_mM[-trainIndex_mM,]

# Variablenauswahl mit VSURF
# ntree standardmäßig 2000
# mtry standardmäßig floor(ncol(train_mN)/3)
VSURF_mM <- VSURF(x = train_mM[,1:196], y = train_mM$mM)
VSURF_mM
# AusgewÃ¤hlte Variablen
VSURF_mM$varselect.pred
colnames(train_mM)[VSURF_mM$varselect.pred] # Spaltennamen
train_mM.vsurf <- train_mM[,colnames(train_mM)[VSURF_mM$varselect.pred]] # neuen Dataframe mit ausgewählten Spalten erzeugen
train_mM.vsurf$mM <- train_mM$mM # Spalte mN hinzufügen
# 8 Bänder
# "b56"  "b220" "b136" "b224" "b112" "b54"  "b3"   "b1"

# rf modell mit ausgewähten Variablen
ctrl <- trainControl(method = 'cv', number = 10) # Kreuzvalidierung
tuneGrid <- expand.grid(.mtry = c(2,3)) # mtry festlegen
set.seed(13674) 
model.mM <- train(mM ~ ., 
                  data = train_mM.vsurf, 
                  method = 'rf', 
                  trControl = ctrl, 
                  tuneGrid = tuneGrid, 
                  ntree = 1000) 
model.mM

# nrmse training
nrmse.train.M <- 0.2291397 / (max(train_mM$mM) - min(train_mM$mM)) * 100

# Variable importance plot
varimp.mM <- varImp(model.mM)

importance.mM <- ggplot(varimp.mM) +
  ggtitle("model.mM")

# Modell auf Testdaten anwenden
predict.mM <- predict(model.mM, newdata = test_mM) 

# Modellgüte berechnen
mM.values <- postResample(pred = predict.mM, obs = test_mM$mM)
nrmse.test.M <- mM.values[1] / (max(test_mM$mM) - min(test_mM$mM)) * 100

# predicted vs. observed
plot_mM <- ggplot(mapping = aes(x = predict.mM, y = test_mM$mM)) +
  geom_point() +
  xlim(range(test_mM$mM)) +
  ylim(range(test_mM$mM)) +
  ggtitle("Feuchte (M)") +
  xlab("Vorhersage") +
  ylab("Beobachtung") +
  geom_abline(color = "grey", linetype = 2) +
  annotate("text", x = Inf, y = -Inf, label = paste("R² =", round(mM.values[2], 3)),
           hjust = 1.18, vjust = -3.5) +
  annotate("text", x = Inf, y = -Inf, label = paste("RMSE =", round(mM.values[1], 3)),
           hjust = 1.127, vjust = -1.5) +
  theme_bw()
plot_mM

### Modell mR ###

# Datensatz mR erstellen
# nur die MW,  die auch für Indikatorwert verwendet wurden herausfiltern
rf.EIVE_mR <- merge(exvals3, EIVE_mean, by = "MW") %>% 
  select(-mN, -mM, -mL, -mT) 
rf.EIVE_mR <- rf.EIVE_mR[,5:201] # nur Bänder und Indikatorwert verwenden

# Datensatz aufteilen
# zu 2647 ändern, damit gleiche Aufteilung
set.seed(2647)
trainIndex_mR <- createDataPartition(rf.EIVE_mR$mR, p = .80, list = FALSE)
train_mR <- rf.EIVE_mR[trainIndex_mR,]
test_mR  <- rf.EIVE_mR[-trainIndex_mR,]

# Variablenauswahl mit VSURF
# ntree standardmäßig 2000
# mtry standardmäßig floor(ncol(train_mN)/3)
VSURF_mR <- VSURF(x = train_mR[,1:196], y = train_mR$mR)
VSURF_mR
# AusgewÃ¤hlte Variablen
VSURF_mR$varselect.pred
colnames(train_mR)[VSURF_mR$varselect.pred] # Spaltennamen
train_mR.vsurf <- train_mR[,colnames(train_mR)[VSURF_mR$varselect.pred]] # neuen Dataframe mit ausgewählten Spalten erzeugen
train_mR.vsurf$mR <- train_mR$mR # Spalte mN hinzufügen
# 13 Bänder
# "b112" "b123" "b56"  "b220" "b55"  "b116" "b78"  "b136" "b51"  "b57"  "b169" "b108" "b4"  

# rf modell mit ausgewähten Variablen
ctrl <- trainControl(method = "cv", number = 10) # Kreuzvalidierung
tuneGrid <- expand.grid(.mtry = c(4,5)) # mtry festlegen
set.seed(1367874) 
model.mR <- train(mR ~ ., 
                  data = train_mR.vsurf, 
                  method = 'rf', 
                  trControl = ctrl, 
                  tuneGrid = tuneGrid, 
                  ntree = 1000) 
model.mR

# nrmse training
nrmse.train.R <- 0.2409292 / (max(train_mR$mR) - min(train_mR$mR)) * 100

# Variable importance plot
varimp.mR <- varImp(model.mR)

importance.mR <- ggplot(varimp.mR) +
  ggtitle("model.mR")

# Modell auf Testdaten anwenden
predict.mR <- predict(model.mR, newdata = test_mR) 

# Modellgüte berechnen
mR.values <- postResample(pred = predict.mR, obs = test_mR$mR)
nrmse.test.R <- mR.values[1] / (max(test_mR$mR) - min(test_mR$mR)) * 100

# predicted vs. observed
plot_mR <- ggplot(mapping = aes(x = predict.mR, y = test_mR$mR)) +
  geom_point() +
  xlim(range(test_mR$mR)) +
  ylim(range(test_mR$mR)) +
  ggtitle("Reaktion (R)") +
  xlab("Vorhersage") +
  ylab("Beobachtung") +
  geom_abline(color = "grey", linetype = 2) +
  annotate("text", x = Inf, y = -Inf, label = paste("R² =", round(mR.values[2], 3)),
           hjust = 1.18, vjust = -3.5) +
  annotate("text", x = Inf, y = -Inf, label = paste("RMSE =", round(mR.values[1], 3)),
           hjust = 1.127, vjust = -1.5) +
  theme_bw()
plot_mR

### Modell mT ###

# Datensatz mT erstellen
# nur die MW,  die auch für Indikatorwert verwendet wurden herausfiltern
rf.EIVE_mT <- merge(exvals3, EIVE_mean, by = "MW") %>% 
  select(-mN, -mM, -mL, -mR) 
rf.EIVE_mT <- rf.EIVE_mT[,5:201] # nur Bänder und Indikatorwert verwenden

# Datensatz aufteilen
# zu 2647 ändern, damit gleiche Aufteilung
set.seed(2647)
trainIndex_mT <- createDataPartition(rf.EIVE_mT$mT, p = .80, list = FALSE)
train_mT <- rf.EIVE_mT[trainIndex_mT,]
test_mT  <- rf.EIVE_mT[-trainIndex_mT,]

# Variablenauswahl mit VSURF
# ntree standardmäßig 2000
# mtry standardmäßig floor(ncol(train_mN)/3)
VSURF_mT <- VSURF(x = train_mT[,1:196], y = train_mT$mT)
VSURF_mT
# AusgewÃ¤hlte Variablen
VSURF_mT$varselect.pred
colnames(train_mT)[VSURF_mT$varselect.pred] # Spaltennamen
train_mT.vsurf <- train_mT[,colnames(train_mT)[VSURF_mT$varselect.pred]] # neuen Dataframe mit ausgewählten Spalten erzeugen
train_mT.vsurf$mT <- train_mT$mT # Spalte mN hinzufügen
# 8 Bänder
# "b56"  "b220" "b112" "b128" "b54"  "b4"   "b136" "b170" 

# rf modell mit ausgewähten Variablen
ctrl <- trainControl(method = "cv", number = 10) # Kreuzvalidierung
tuneGrid <- expand.grid(.mtry = c(2, 3)) # mtry festlegen
set.seed(1367874) 
model.mT <- train(mT ~ ., 
                  data = train_mT.vsurf, 
                  method = 'rf', 
                  trControl = ctrl, 
                  tuneGrid = tuneGrid, 
                  ntree = 1000) 
model.mT

# nrmse training
nrmse.train.T <- 0.09014440 / (max(train_mT$mT) - min(train_mT$mT)) * 100

# Variable importance plot
varimp.mT <- varImp(model.mT)

importance.mT <- ggplot(varimp.mT) +
  ggtitle("model.mT")

# Modell auf Testdaten anwenden
predict.mT <- predict(model.mT, newdata = test_mT) 

# Modellgüte berechnen
mT.values <- postResample(pred = predict.mT, obs = test_mT$mT)
# nrmse
nrmse.test.T <- mT.values[1] / (max(test_mT$mT) - min(test_mT$mT)) * 100

# predicted vs. observed
plot_mT <- ggplot(mapping = aes(x = predict.mT, y = test_mT$mT)) +
  geom_point() +
  xlim(range(test_mT$mT)) +
  ylim(range(test_mT$mT)) +
  ggtitle("Temperatur (T)") +
  xlab("Vorhersage") +
  ylab("Beobachtung") +
  geom_abline(color = "grey", linetype = 2) +
  annotate("text", x = Inf, y = -Inf, label = paste("R² =", round(mT.values[2], 3)),
           hjust = 1.18, vjust = -3.5) +
  annotate("text", x = Inf, y = -Inf, label = paste("RMSE =", round(mT.values[1], 3)),
           hjust = 1.127, vjust = -1.5) +
  theme_bw()
plot_mT

# Indikatorplots zusammen
Indicator_plot.line <- grid.arrange(plot_mN, plot_mM, plot_mR, plot_mT, nrow = 1, ncol = 4)
Indicator_plot <- grid.arrange(plot_mN, plot_mM, plot_mR, plot_mT, nrow = 2, ncol = 2)
ggsave(Indicator_plot.line, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/Indicator_plotline.png",
       width = 40, height = 10, units = "cm")

ggsave(Indicator_plot, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/Indicator_plot.png")

# Importance Plots zusammen
Band_importance <- grid.arrange(importance.mN, importance.mM, importance.mR, nrow = 1, ncol = 3)
ggsave(Band_importance, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/Band.importance_plot.png",
       width = 30, height = 10, units = "cm")


# Visualisierung wichtige Bänder
bands.mN <- colnames(train_mN)[VSURF_mN$varselect.pred]
bands.mN2 <-   wavelength %>%
  filter(bands %in% bands.mN)

bands.mM <- colnames(train_mM)[VSURF_mM$varselect.pred]
bands.mM2 <-   wavelength %>%
  filter(bands %in% bands.mM)

bands.mR <- colnames(train_mR)[VSURF_mR$varselect.pred]
bands.mR2 <-   wavelength %>%
  filter(bands %in% bands.mR)

bands.mT <- colnames(train_mT)[VSURF_mT$varselect.pred]
bands.mT2 <-   wavelength %>%
  filter(bands %in% bands.mT)

relevant_wavelengths <- bind_rows(
  mutate(bands.mN2, Indikator = "Stickstoff (N)"),
  mutate(bands.mM2, Indikator = "Feuchte (M)"),
  mutate(bands.mR2, Indikator = "Reaktion (R)"),
  mutate(bands.mT2, Indikator = "Temperatur (T)")
)

relevant_wavelengths <- relevant_wavelengths %>%
  mutate(Indikator = factor(Indikator, levels = c("Temperatur (T)", "Reaktion (R)", "Feuchte (M)", "Stickstoff (N)")))

relevant_wavelengths$wavelength <- as.numeric(relevant_wavelengths$wavelength)

# Plot erstellen
important_wavelength <- ggplot(relevant_wavelengths, aes(x = wavelength, y = Indikator)) +
  geom_rect(xmin = 380, xmax = 430, ymin = -Inf, ymax = Inf, fill = "#FFBBFF", alpha = 0.03) +
  geom_rect(xmin = 430, xmax = 490, ymin = -Inf, ymax = Inf, fill = "cyan", alpha = 0.03) +
  geom_rect(xmin = 490, xmax = 570, ymin = -Inf, ymax = Inf, fill = "green", alpha = 0.03) +
  geom_rect(xmin = 570, xmax = 600, ymin = -Inf, ymax = Inf, fill = "yellow", alpha = 0.03) +
  geom_rect(xmin = 600, xmax = 640, ymin = -Inf, ymax = Inf, fill = "orange", alpha = 0.03) +
  geom_rect(xmin = 640, xmax = 780, ymin = -Inf, ymax = Inf, fill = "red", alpha = 0.03) +
  geom_vline(xintercept = 418.416, linetype = "dashed", color = "gray73") + 
  geom_vline(xintercept = 2445.300, linetype = "dashed", color = "gray73") +
  geom_rect(xmin = 895.789, xmax = 993.338, ymin = -Inf, ymax = Inf, fill = "gray88", alpha = 0.1) + 
  geom_rect(xmin = 1342.82, xmax = 1390.48, ymin = -Inf, ymax = Inf, fill = "gray88", alpha = 0.1) +
  geom_rect(xmin = 1781, xmax = 1967, ymin = -Inf, ymax = Inf, fill = "gray88", alpha = 0.1) +
  geom_errorbar(aes(ymin = Indikator, ymax = Indikator), width = 2, size = 7) +
  labs(x = "Wellenlänge [nm]", y = "Indikatoren") +
  theme_bw()

ggsave(important_wavelength, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/important_wl_RF.png",
       width = 30, height = 10, units = "cm")

#### end ####

#### 12.) Random Forest Modell Klassen ####

# caret package: https://topepo.github.io/caret/index.html
# Übersicht Models: https://rdrr.io/cran/caret/man/models.html
# Tutorials: 
# https://topepo.github.io/caret/index.html
# https://www.guru99.com/r-random-forest-tutorial.html 
# https://stackoverflow.com/questions/57939453/building-a-randomforest-with-caret
# https://machinelearningmastery.com/tune-machine-learning-algorithms-in-r/
# https://www.youtube.com/watch?v=rTphHY9Chgk

modelLookup("rf")
# mtry relevant 

### für 5 Klassen

# Datensatz bearbeiten
# predictor: Bänder
# response: Klassen
# nur die MW,  die auch für Klassifikation verwendet wurden
rf.classes <- merge(exvals3, classes.dataframe, by = "MW") 
str(rf.classes$classes) # passt (classes muss Faktor sein)
rf.classes <- rf.classes[,5:201] # nur Bänder und Klassen verwenden

# Datensatz in Training und Test unterteilen (80% Training, 20% Test)
# Verteilung der Klassen wird beachtet -> Anteile in Test und Training ca gleich
set.seed(34597)
trainIndex_classes <- createDataPartition(rf.classes$classes, p = .8, list = FALSE) # Daten werden nicht als Liste zurückgegeben
train_classes <- rf.classes[ trainIndex_classes,] # 728 MW
test_classes  <- rf.classes[-trainIndex_classes,] # 180 MW

# Verteilung der Klassen
sum(train_classes$classes == "Klasse 1") # 93
sum(train_classes$classes == "Klasse 2") # 261
sum(train_classes$classes == "Klasse 3") # 158
sum(train_classes$classes == "Klasse 4") # 140
sum(train_classes$classes == "Klasse 5") # 76
# Klassen sollten gleichgroß sein -> downsamplen

# down-sampling
set.seed(960)
train_classes.down <- downSample(x = train_classes[, -ncol(train_classes)],
                                 y = train_classes$classes,
                                 yname = "classes")

# Variablenauswahl mit VSURF
# ntree standardmäßig 2000
# mtry standardmäßig floor(ncol(train_mN)/3)
VSURF_classes <- VSURF(x = train_classes.down[,1:196], y = train_classes.down$classes)
VSURF_classes
# AusgewÃ¤hlte Variablen
VSURF_classes$varselect.pred
colnames(train_classes.down)[VSURF_classes$varselect.pred] # Spaltennamen
train_classes.vsurf <- train_classes.down[,colnames(train_classes.down)[VSURF_classes$varselect.pred]] # neuen Dataframe mit ausgewählten Spalten erzeugen
train_classes.vsurf$classes <- train_classes.down$classes # Spalte classes hinzufügen
# 7 Bänder
# "b220" "b224" "b55"  "b1"   "b171" "b223" "b218"

# Training 
# Anzahl der Bäume mind. 1000 (ausprobieren, ob mehr benötigt werden) (Kuhn)
# Kuhns Empfehlung mtry: tuneLength = 5
# mtry sollte Wurzel aus Anzahl predictor sein (Breiman)

ctrl <-  trainControl(method = 'repeatedcv', number = 10, repeats = 10)
tuneGrid <- expand.grid(.mtry = c(2,3)) # mtry definieren
set.seed(13) 
model.classes <- train(classes ~ ., 
                       data = train_classes.vsurf, 
                       method = 'rf', 
                       trControl = ctrl,
                       tuneGrid = tuneGrid, 
                       ntree = 1000) 
model.classes

# Variable importance plot
varimp.classes <- varImp(model.classes)
plot(varimp.classes)

# Anwendung Modell auf Testdaten
predict.classes <- predict(model.classes, newdata = test_classes)

# class Wahrscheinlichkeiten -> mit welcher Wahrscheinlichkeit wird Wiese einer Klasse zugeordnet
predictedProbs.classes <- predict(model.classes, newdata = test_classes, type = "prob")
head(predictedProbs.classes)

# Konfusionsmatrix erstellen
confusionMatrix(data = predict.classes, reference = test_classes$classes, mode = "everything") 
postResample(pred = predict.classes, obs = test_classes$classes) # hier nochmal Modellgüte separat

### für 4 Klassen -> deutlich bessere Werte

rf.classes4 <- merge(exvals3, classes4.dataframe, by = "MW") 
str(rf.classes4$classes) 
rf.classes4 <- rf.classes4[,5:201] 

set.seed(34597)
trainIndex_classes4 <- createDataPartition(rf.classes4$classes, p = .8, list = FALSE) # Daten werden nicht als Liste zurückgegeben
train_classes4 <- rf.classes4[ trainIndex_classes4,] # 728 MW
test_classes4  <- rf.classes4[-trainIndex_classes4,] # 180 MW

# Verteilung der Klassen
sum(train_classes4$classes == "Klasse 1") 
sum(train_classes4$classes == "Klasse 2") 
sum(train_classes4$classes == "Klasse 3") 
sum(train_classes4$classes == "Klasse 4") 
# Klassen sollten gleichgroß sein -> downsamplen

# down-sampling
set.seed(934)
train_classes4.down <- downSample(x = train_classes4[, -ncol(train_classes4)],
                                 y = train_classes4$classes,
                                 yname = "classes")

# Variablenauswahl mit VSURF
# ntree standardmäßig 2000
# mtry standardmäßig floor(ncol(train_mN)/3)
set.seed(14)
VSURF_classes4 <- VSURF(x = train_classes4.down[,1:196], y = train_classes4.down$classes)
VSURF_classes4
# AusgewÃ¤hlte Variablen
VSURF_classes4$varselect.pred
colnames(train_classes4.down)[VSURF_classes4$varselect.pred] # Spaltennamen
train_classes4.vsurf <- train_classes4.down[,colnames(train_classes4.down)[VSURF_classes4$varselect.pred]] # neuen Dataframe mit ausgewählten Spalten erzeugen
train_classes4.vsurf$classes <- train_classes4.down$classes # Spalte classes hinzufügen
# 6 Bänder
# "b56"  "b112" "b171" "b130" "b1"   "b220"

# Training 
# Anzahl der Bäume mind. 1000 (ausprobieren, ob mehr benötigt werden) (Kuhn)
# Kuhns Empfehlung mtry: tuneLength = 5
# mtry sollte Wurzel aus Anzahl predictor sein (Breiman)

ctrl <-  trainControl(method = 'cv', number = 10)
tuneGrid <- expand.grid(.mtry = c(2,3)) # mtry definieren
set.seed(193) 
model.classes4 <- train(classes ~ ., 
                       data = train_classes4.vsurf, 
                       method = 'rf', 
                       trControl = ctrl,
                       tuneGrid = tuneGrid, 
                       ntree = 1000) 
model.classes4

# Variable importance plot
varimp.classes4 <- varImp(model.classes4)
plot(varimp.classes4)

# Anwendung Modell auf Testdaten
predict.classes4 <- predict(model.classes4, newdata = test_classes4)

# class Wahrscheinlichkeiten -> mit welcher Wahrscheinlichkeit wird Wiese einer Klasse zugeordnet
predictedProbs.classes4 <- predict(model.classes4, newdata = test_classes4, type = "prob")
head(predictedProbs.classes4)

# Konfusionsmatrix erstellen
confusionMatrix(data = predict.classes4, reference = test_classes4$classes, mode = "everything") 
postResample(pred = predict.classes4, obs = test_classes4$classes) # hier nochmal Modellgüte separat

#### end ####

#### 13.) Erstellung von Karten ####
# MW Polygon laden und verwendete MW herausfiltern
setwd("C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/Daten Maehwiesen")
mw.poly2 <- st_read("FFH-Maehwiese/FFH-Maehwiese_polygon.shp")
mw.poly2.filtered <- mw.poly2[mw.poly2$MW_NUMMER %in% classes4.dataframe$MW, ]
plot(mw.poly2.filtered, max.plot = 1) # schonmal anschauen

# Polygone als Punkte
poly2.points <- st_centroid(mw.poly2.filtered) %>%
  rename(MW = MW_NUMMER) # MW_NUMMER umbenennen
# st_write(poly2.points, "MW.points.shp")
poly2.points <- merge(poly2.points, classes4.dataframe, by = "MW") # classes hinzufügen
poly2.points <- merge(poly2.points, EIVE_mean, by = "MW") # Indikatorwerte hinzufügen
poly2.points$classes <- as.factor(poly2.points$classes)

# Plot erstellen
# für Klassen
Lage_Klassen <- ggplot() +
  geom_sf(data = poly2.points, size = 0.9, aes(color = classes)) +
  scale_color_manual(values = c("Klasse 1" = "#4A708B", "Klasse 2" = "#43CD80", "Klasse 3" = "#EE8262", "Klasse 4" = "#CDB5CD")) +
  theme_bw() +
  guides(color = guide_legend(title = "Klassen", override.aes = list(size = 3)))

ggsave(Lage_Klassen, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/Lage_Klassen.png")

# für EIVE
ggplot() +
  geom_sf(data = poly2.points, aes(color = mN), size = 0.9) +
  scale_color_gradient(low = "blue", high = "red")


#### end ####

#### 14.) Wellenlängen Plots ####
# Wellenlängen aus XML lesen
# https://stackoverflow.com/questions/13579996/how-to-create-an-r-data-frame-from-an-xml-file
setwd("C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/Daten Satellit 2")
list.files()
w_xml <- xmlParse("ENMAP01-____L2A-DT0000042060_20230914T105746Z_022_V010400_20231114T142140Z-METADATA.XML")  
wavelength <- xmlToDataFrame(getNodeSet(w_xml, "//bandStatistics//waveLength")) %>%
  rename(wavelength = text)
bands <- paste("b", 1:224, sep = "")
wavelength <- data.frame(bands = bands, wavelength = wavelength)

write.csv(wavelength, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/wavelength.csv")

# Basic Plot
plot(wavelength$wavelength, exvals2[1,5:228], type = "l")

# interaktiven Plot erstellen mit plotly
# https://plotly.com/r/time-series/
# exvals2 ins richtige Format bringen
exvals_plot <- subset(exvals2, select = -c(ID, npix.used, npix.poly)) # unwichtige Spalten löschen
rownames(exvals_plot) <- exvals_plot$MW # MW als Zeilennamen
exvals_plot <- t(exvals_plot) # Zeilen und Spalten vertauschen
exvals_plot <- exvals_plot[-which(rownames(exvals_plot) == "MW"), ] # Zeile MW entfernen
exvals_plot <- as.data.frame(exvals_plot)
exvals_plot$wavelength <- wavelength$wavelength # Spalte wavlength hinzufügen
exvals_plot <- exvals_plot[ , c("wavelength", names(exvals_plot)[names(exvals_plot) != "wavelength"])] # an erste Stelle
identical(exvals_plot$wavelength, wavelength$wavelength) # passt
# character Spalten in numeric umwandeln
exvals_plot[] <- lapply(exvals_plot, function(x) if(is.character(x)) as.numeric(as.character(x)) else x)
# Spalte wavelength in character -> nicht nötig
# exvals_plot$wavelength <- as.character(exvals_plot$wavelength)

# 1780.22 - 1967.66 -> zwischen b166 und b167 größerer WL Sprung -> Satellit hat Bereich um Wasserdampf (1850nm) nicht aufgezeichnet
# NA Zeile hinzufügen, damit es keine durchgängige Linie in diesem Bereich gibt
NAZeile <- vector("numeric", length = ncol(exvals_plot))
NAZeile[1] <- 1900
NAZeile[-1] <- NA
exvals_plot <- rbind(exvals_plot, NAZeile)
exvals_plot <- exvals_plot[order(exvals_plot$wavelength), ] # aufsteigend sortieren

# spektrale Signatur der Wiesen plotten
EIVE_mean[which.min(EIVE_mean$mN),] # 6510011946224756, mN = 3.635179
EIVE_mean[which.max(EIVE_mean$mN),] # 6510011946231766, mN = 5.752171
EIVE_mean[which.min(EIVE_mean$mM),] # 6510012846207407, mM = 3.547297
EIVE_mean[which.max(EIVE_mean$mM),] # 6510012546219105, mM = 5.219563
EIVE_mean[which.min(EIVE_mean$mR),] # 6510011946232229, mR = 5.218783
EIVE_mean[which.max(EIVE_mean$mR),] # 6510012846216559, mR = 7.160248

# Plot erstellen
plot_WL <- plot_ly(exvals_plot, type = 'scatter', mode = 'lines') %>%
  add_trace(x = ~wavelength, y = ~`6510011946224756`, name = "min mN") %>%
  add_trace(x = ~wavelength, y = ~`6510011946231766`, name = "max mN") %>%
  add_trace(x = ~wavelength, y = ~`6510012846207407`, name = "min mM") %>%
  add_trace(x = ~wavelength, y = ~`6510012546219105`, name = "max mM") %>%
  add_trace(x = ~wavelength, y = ~`6510011946232229`, name = "min mR") %>%
  add_trace(x = ~wavelength, y = ~`6510012846216559`, name = "max mR")
# %>% layout(showlegend = F) # Legede wird verborgen
plot_WL <- plot_WL %>%
  layout(
    xaxis = list(zerolinecolor = '#ffff',
                 zerolinewidth = 2,
                 gridcolor = 'ffff',
                 title = 'Wellenlänge [nm]'),
    yaxis = list(zerolinecolor = '#ffff',
                 zerolinewidth = 2,
                 gridcolor = 'ffff',
                 title = "Intensität"),
    plot_bgcolor='#e5ecf6', width = 900)

plot_WL

# Plot bearbeiten
# bei Intensitätsschwankungen Werte NA setzen, b79 (895.789) bis b101 (993.338) 
exvals_plot2 <- exvals_plot
exvals_plot2[79:101, 2:3394] <- NA

# Plot 2 erstellen
plot_WL2 <- plot_ly(exvals_plot2, type = 'scatter', mode = 'lines') %>%
  add_trace(x = ~wavelength, y = ~`6510011946224756`, name = "min mN") %>%
  add_trace(x = ~wavelength, y = ~`6510011946231766`, name = "max mN") %>%
  add_trace(x = ~wavelength, y = ~`6510012846207407`, name = "min mM") %>%
  add_trace(x = ~wavelength, y = ~`6510012546219105`, name = "max mM") %>%
  add_trace(x = ~wavelength, y = ~`6510011946232229`, name = "min mR") %>%
  add_trace(x = ~wavelength, y = ~`6510012846216559`, name = "max mR")
# %>% layout(showlegend = F) # Legede wird verboren
plot_WL2 <- plot_WL2 %>%
  layout(
    xaxis = list(zerolinecolor = '#ffff',
                 zerolinewidth = 2,
                 gridcolor = 'ffff',
                 title = 'Wellenlänge [nm]'),
    yaxis = list(zerolinecolor = '#ffff',
                 zerolinewidth = 2,
                 gridcolor = 'ffff',
                 title = "Intensität"),
    plot_bgcolor='#e5ecf6', width = 900)

plot_WL2

# mit ggplot für BA, Bereich der ausgeschnitten ist soll grau hinterlegt sein
eine.wiese1 <- exvals_plot[, c("wavelength", "6510011946232229")] %>% 
  rename(Wiese1 = `6510011946232229`)
eine.wiese2 <- exvals_plot2[, c("wavelength", "6510011946232229")] %>% 
  rename(Wiese2 = `6510011946232229`)

eine.wiese <- merge(eine.wiese1, eine.wiese2, by = "wavelength")

eine.wiese.plot <- ggplot(eine.wiese, aes(x = wavelength)) +
  geom_line(aes(y = Wiese1), color = "grey", size = 0.5) +
  geom_line(aes(y = Wiese2), color = "black", size = 0.5) +
  labs(x = "Wellenlänge [nm]", y = "Reflexion") +
  theme_bw()

ggsave(eine.wiese.plot, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/eine.wiese.plot.png",
       width = 20, height = 10, units = "cm")


#### end ####

#### 15.) MW als shape files ####
# MW Polygon laden und verwendete LRT herausfiltern
setwd("C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/Daten Maehwiesen")
mw.poly3 <- vect("FFH-Maehwiese/FFH-Maehwiese_polygon.shp") 

rf.LRT <- mutate(exvals3, LRT_NAME = mw.poly3$LRT_NAME[exvals3$ID]) %>% 
  filter(MW %in% classes.dataframe$MW) %>%
  select(!ID) %>%
  select(!npix.used) %>%
  select(!npix.poly)

sum(rf.LRT$LRT_NAME == "Magere Flachland-Mähwiesen") # 887 mal
sum(rf.LRT$LRT_NAME == "Berg-Mähwiesen") # 21 mal

# Datensatz Magere Flachlandwiese
rf.LRT.flach <- rf.LRT %>%
  filter(LRT_NAME == "Magere Flachland-Mähwiesen")

# MW Polygon laden und verwendete MW herausfiltern (mw.poly2 siehe Erstellung Karte)
mw.poly.flach <- mw.poly2[mw.poly2$MW_NUMMER %in% rf.LRT.flach$MW, ]

# Polygone als Punkte
poly.flach.points <- st_centroid(mw.poly.flach) %>%
  rename(MW = MW_NUMMER) # MW_NUMMER umbenennen
st_write(poly.flach.points, "MW.flach.shp")

# Datensatz Bergmähwiesen
rf.LRT.berg <- rf.LRT %>%
  filter(LRT_NAME == "Berg-Mähwiesen")

# MW Polygon laden und verwendete MW herausfiltern (mw.poly2 siehe Erstellung Karte)
mw.poly.berg <- mw.poly2[mw.poly2$MW_NUMMER %in% rf.LRT.berg$MW, ]

# Polygone als Punkte
poly.berg.points <- st_centroid(mw.poly.berg) %>%
  rename(MW = MW_NUMMER) # MW_NUMMER umbenennen
st_write(poly.berg.points, "MW.berg.shp")

# die verschiedenen Klassen
# Klasse 1
Klasse1 <- subset(classes4.dataframe, classes == "Klasse 1")
mw.Klasse1 <- mw.poly2[mw.poly2$MW_NUMMER %in% Klasse1$MW, ]
poly.Klasse1 <- st_centroid(mw.Klasse1) %>%
  rename(MW = MW_NUMMER) # MW_NUMMER umbenennen
st_write(poly.Klasse1, "poly.Klasse1.shp")

# Klasse 2
Klasse2 <- subset(classes4.dataframe, classes == "Klasse 2")
mw.Klasse2 <- mw.poly2[mw.poly2$MW_NUMMER %in% Klasse2$MW, ]
poly.Klasse2 <- st_centroid(mw.Klasse2) %>%
  rename(MW = MW_NUMMER) # MW_NUMMER umbenennen
st_write(poly.Klasse2, "poly.Klasse2.shp")

# Klasse 3
Klasse3 <- subset(classes4.dataframe, classes == "Klasse 3")
mw.Klasse3 <- mw.poly2[mw.poly2$MW_NUMMER %in% Klasse3$MW, ]
poly.Klasse3 <- st_centroid(mw.Klasse3) %>%
  rename(MW = MW_NUMMER) # MW_NUMMER umbenennen
st_write(poly.Klasse3, "poly.Klasse3.shp")

# Klasse 4
Klasse4 <- subset(classes4.dataframe, classes == "Klasse 4")
mw.Klasse4 <- mw.poly2[mw.poly2$MW_NUMMER %in% Klasse4$MW, ]
poly.Klasse4 <- st_centroid(mw.Klasse4) %>%
  rename(MW = MW_NUMMER) # MW_NUMMER umbenennen
st_write(poly.Klasse4, "poly.Klasse4.shp")

#### end ####

#### 16.) mittlere Intensitäten für jede Klasse ####
mean_classes <- aggregate(. ~ classes, data = rf.classes4, FUN = mean)
exvals_plot3 <- t(mean_classes) # Zeilen und Spalten vertauschen
as.data.frame(exvals_plot3)
colnames(exvals_plot3) <- as.character(unlist(exvals_plot3[1, ]))
exvals_plot3 <- exvals_plot3[-1, ]
exvals_plot3 <- merge(exvals_plot3, wavelength, by.x = "row.names", by.y = "bands") # beide Dataframes zusammen
# alles bis auf bands in numeric umwandeln
exvals_plot3[, -1] <- lapply(exvals_plot3[, -1], function(x) if(is.character(x)) as.numeric(as.character(x)) else x)
exvals_plot3 <- exvals_plot3[order(exvals_plot3$wavelength), ] # wavelength aufsteigend sortieren

colnames(exvals_plot3) <- make.names(colnames(exvals_plot3))

# Na Zeilen erzeugen, damit keine durchgezogenen Linien
exvals_plot3 <- exvals_plot3[ , c("wavelength", names(exvals_plot3)[names(exvals_plot3) != "wavelength"])] # an erste Stelle
NAZeile2 <- vector("numeric", length = ncol(exvals_plot3))
NAZeile2[1] <- 1900
NAZeile2[-1] <- NA
exvals_plot3 <- rbind(exvals_plot3, NAZeile2)

NAZeile3 <- vector("numeric", length = ncol(exvals_plot3))
NAZeile3[1] <- 1400
NAZeile3[-1] <- NA
exvals_plot3 <- rbind(exvals_plot3, NAZeile3)

NAZeile4 <- vector("numeric", length = ncol(exvals_plot3))
NAZeile4[1] <- 900
NAZeile4[-1] <- NA
exvals_plot3 <- rbind(exvals_plot3, NAZeile4)

exvals_plot3 <- exvals_plot3[order(exvals_plot3$wavelength), ] # aufsteigend sortieren

# Wellenlänge, an der die Linie markiert werden soll
colnames(train_classes4.down)[VSURF_classes4$varselect.pred]
# "b56"  "b112" "b171" "b130" "b1"   "b220"
mark1 <- 418.416
mark2 <- 720.501
mark3 <- 1116.430
mark4 <- 1330.850
mark5 <- 2005.080
mark6 <- 2415.210

classes.wl.plot <- ggplot(exvals_plot3, aes(x = wavelength)) +
  geom_line(aes(y = Klasse.1, color = "Klasse 1"), size = 0.5) +
  geom_line(aes(y = Klasse.2, color = "Klasse 2"), size = 0.5) +
  geom_line(aes(y = Klasse.3, color = "Klasse 3"), size = 0.5) +
  geom_line(aes(y = Klasse.4, color = "Klasse 4"), size = 0.5) +
  labs(x = "Wellenlänge [nm]", y = "Intensität") +
  scale_color_manual(name = "Klassen",
                     values = c("Klasse 1" = "#4A708B",
                                "Klasse 2" = "#43CD80",
                                "Klasse 3" = "#EE8262",
                                "Klasse 4" = "#CDB5CD"),
                     labels = c("Klasse 1", "Klasse 2", "Klasse 3", "Klasse 4")) +
  geom_point(data = data.frame(x = c(mark1, mark2, mark3, mark4, mark5, mark6), y = 0), aes(x, y, shape = "Ausgewählte Bänder"), color = "black", size = 2) +
  scale_shape_manual(name = "", values = 19, labels = "Ausgewählte Bänder") +
  theme_bw() +
  guides(color = guide_legend(order = 1),
         shape = guide_legend(order = 2))

ggsave(classes.wl.plot, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/classes.wl.plot.png",
       width = 20, height = 10, units = "cm")

# mittlere Intensitäten für jede Klasse (aber mit Trainingsdaten) -> gleiches Vorgehen wie oben

mean_classes.train <- aggregate(. ~ classes, data = train_classes4.down, FUN = mean)
exvals_plot4 <- t(mean_classes.train) # Zeilen und Spalten vertauschen
as.data.frame(exvals_plot4)
colnames(exvals_plot4) <- as.character(unlist(exvals_plot4[1, ]))
exvals_plot4 <- exvals_plot4[-1, ]
exvals_plot4 <- merge(exvals_plot4, wavelength, by.x = "row.names", by.y = "bands") # beide Dataframes zusammen
# alles bis auf bands in numeric umwandeln
exvals_plot4[, -1] <- lapply(exvals_plot4[, -1], function(x) if(is.character(x)) as.numeric(as.character(x)) else x)
exvals_plot4 <- exvals_plot4[order(exvals_plot4$wavelength), ] # wavelength aufsteigend sortieren

colnames(exvals_plot4) <- make.names(colnames(exvals_plot4))

# NA Zeilen hinzufügen
exvals_plot4 <- exvals_plot4[ , c("wavelength", names(exvals_plot4)[names(exvals_plot4) != "wavelength"])] # an erste Stelle
exvals_plot4 <- rbind(exvals_plot4, NAZeile2)
exvals_plot4 <- rbind(exvals_plot4, NAZeile3)
exvals_plot4 <- rbind(exvals_plot4, NAZeile4)

exvals_plot4 <- exvals_plot4[order(exvals_plot4$wavelength), ] # aufsteigend sortieren

classes.wl.plot.train <- ggplot(exvals_plot4, aes(x = wavelength)) +
  geom_line(aes(y = Klasse.1, color = "Klasse 1"), size = 0.5) +
  geom_line(aes(y = Klasse.2, color = "Klasse 2"), size = 0.5) +
  geom_line(aes(y = Klasse.3, color = "Klasse 3"), size = 0.5) +
  geom_line(aes(y = Klasse.4, color = "Klasse 4"), size = 0.5) +
  labs(x = "Wellenlänge [nm]", y = "Reflexion") +
  scale_color_manual(name = "Klassen",
                     values = c("Klasse 1" = "#4A708B",
                                "Klasse 2" = "#43CD80",
                                "Klasse 3" = "#EE8262",
                                "Klasse 4" = "#CDB5CD"),
                     labels = c("Klasse 1", "Klasse 2", "Klasse 3", "Klasse 4")) +
  geom_point(data = data.frame(x = c(mark1, mark2, mark3, mark4, mark5, mark6), y = 0), aes(x, y, shape = "Ausgewählte Bänder"), color = "black", size = 2) +
  scale_shape_manual(name = "", values = 19, labels = "Ausgewählte\nBänder") +
  theme_bw() +
  guides(color = guide_legend(order = 1),
         shape = guide_legend(order = 2))

classes.wl.plot.train

ggsave(classes.wl.plot.train, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/classes.wl.plot.train2.png",
       width = 20, height = 10, units = "cm")

# mit Plotly, damit WL abgelesen werden können
# Plot 2 erstellen
plot_WL4 <- plot_ly(exvals_plot4, type = 'scatter', mode = 'lines') %>%
  add_trace(x = ~wavelength, y = ~Klasse.1, name = "Klasse 1") %>%
  add_trace(x = ~wavelength, y = ~Klasse.2, name = "Klasse 2") %>%
  add_trace(x = ~wavelength, y = ~Klasse.3, name = "Klasse 3") %>%
  add_trace(x = ~wavelength, y = ~Klasse.4, name = "Klasse 4") 

plot_WL4 <- plot_WL4 %>%
  layout(
    xaxis = list(zerolinecolor = '#ffff',
                 zerolinewidth = 2,
                 gridcolor = 'ffff',
                 title = 'Wellenlänge [nm]'),
    yaxis = list(zerolinecolor = '#ffff',
                 zerolinewidth = 2,
                 gridcolor = 'ffff',
                 title = "Intensität"),
    plot_bgcolor='#e5ecf6', width = 900)

plot_WL4

#### end ####
