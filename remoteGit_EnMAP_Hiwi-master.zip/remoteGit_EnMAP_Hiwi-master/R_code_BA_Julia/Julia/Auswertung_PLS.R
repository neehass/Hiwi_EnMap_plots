library(plsRglm)
library(plsdof)
library(caret)
library(dplyr)
library(ggplot2)
setwd("C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code")
source("generalizedPLS_functions.R") # läd die Funktionen aus dem Skript generalizedPLS_functions.R"

exvals3 <- read.csv("exvals3.csv")
EIVE_mean <- read.csv("EIVE_mean.csv")

# Skript wurde immer auf jeweiligen Indikatorwert angepasst

# aufteilen ist trainings und Test datensatz
rf.EIVE <- merge(exvals3, EIVE_mean, by = "MW")
# set.seed wie in anderem Skript damit für jeden Indikatorwert gleiche Aufteilung wie für RF
# für N set.seed(2647)
# für M set.seed(26477)
# für R set.seed(2647)
# für T set.seed(2647)
set.seed(2647) # so gleiche Aufteilung wie bei RF
trainIndex <- createDataPartition(rf.EIVE$mR, p = .80, list = FALSE) # caret
traind <- rf.EIVE[trainIndex,]
testd  <- rf.EIVE[-trainIndex,]

# Indikatorwerte (anpassen)
colnames(traind)
resp <- traind[,"mR"] # response
preds <- traind[,c(6:201)] # predictors 
dat <- cbind(resp, preds)
wei <- traind[,"npix.used"]
testresp <- testd[,"mR"]
testpred <- testd[,c(6:201)]

# Partial least squares regression mit variable selection
# selbst geschriebene Funktion aus dem Skript generalizedPLS_functions.R
df <- dat
output.mR <- gpls_vs(df = dat) 
# get bands included in the best model
df.final <- output.mR[[2]]
bands <- colnames(df.final[,-1])
bands
# run plsr again with selected bands
plsr.mR <- plsR(resp ~ ., data = df.final, nt=10, modele="pls", verbose=TRUE)
# predicted vs. observed for the training dataset
# plot(plsr.mN$ValsPredictY, plsr.mN$dataY)
# abline(0,1)
# r-squared for the training dataset
Rsquared.training <- cor(plsr.mR$dataY, plsr.mR$ValsPredictY)^2
rmse.training <- sqrt(mean((plsr.mR$dataY - plsr.mR$ValsPredictY)^2)) 
nrmse.training <- rmse.training / (max(plsr.mR$dataY) - min(plsr.mR$dataY)) * 100 
# same for the test dataset
testpred <- testpred[,bands]
predicted <- predict.plsRmodel(object = plsr.mR, newdata=testpred, type = "response")
# plot(predicted, testresp)
# abline(0,1)
Rsquared.test <- cor(testresp, predicted)^2

# wie man an das r-squared in cross validation rankommt muss ich nochmal schauen

# RMSE
rmse <- sqrt(mean((testresp - predicted)^2))
nrmse <- rmse / (max(testresp) - min(testresp)) * 100 # in Tabelle nrmse mit angeben

# Aus Uebung Teil 2 Masterskript
# Root mean squared error
# rmse <- sqrt(mean((ellenberg$cwmN - predict(rfN))^2))
# Normalize Root mean squared error
# nrmse <- rmse / (max(ellenberg$cwmN) - min(ellenberg$cwmN)) * 100
# hier habe ich die range für die Normalisierung verwendet,
# Manchmal wird auch die Standartabweichung verwendet (Berechnungsmethode deshalb
# immer in den Methoden angeben)

# Ergebnisse für mN
bands.mN <- bands
predicted.mN <- predicted
testresp.mN <- testresp
Rsquared.training.mN <- Rsquared.training
Rsquared.test.mN <- Rsquared.test
rmse.training.mN <- rmse.training
rmse.test.mN <- rmse
nrmse.training.mN <- nrmse.training
nrmse.test.mN <- nrmse
Ergebnnisse.mN <- cbind(Rsquared.training.mN, Rsquared.test.mN, rmse.training.mN, rmse.test.mN, nrmse.training.mN, nrmse.test.mN)

plot_mN <- ggplot(mapping = aes(x = predicted.mN, y = testresp.mN)) +
  geom_point() +
  xlim(range(testresp.mN)) +
  ylim(range(testresp.mN)) +
  ggtitle("Stickstoff (N)") +
  xlab("Vorhersage") +
  ylab("Beobachtung") +
  # geom_smooth(method = "lm", fill= "lightblue") 
  geom_abline(color = "grey", linetype = 2) +
  annotate("text", x = Inf, y = -Inf, label = paste("R² =", round(Rsquared.test.mN, 3)),
           hjust = 1.18, vjust = -3.5) +
  annotate("text", x = Inf, y = -Inf, label = paste("RMSE =", round(rmse.test.mN, 3)), 
           hjust = 1.127, vjust = -1.5) +
  theme_bw()
plot_mN


# Ergebnisse für mM
bands.mM <- bands
predicted.mM <- predicted
testresp.mM <- testresp
Rsquared.training.mM <- Rsquared.training
Rsquared.test.mM <- Rsquared.test
rmse.training.mM <- rmse.training
rmse.test.mM <- rmse
nrmse.training.mM <- nrmse.training
nrmse.test.mM <- nrmse
Ergebnnisse.mM <- cbind(Rsquared.training.mM, Rsquared.test.mM, rmse.training.mM, rmse.test.mM, nrmse.training.mM, nrmse.test.mM)

plot_mM <- ggplot(mapping = aes(x = predicted.mM, y = testresp.mM)) +
  geom_point() +
  xlim(range(testresp.mM)) +
  ylim(range(testresp.mM)) +
  ggtitle("Feuchte (M)") +
  xlab("Vorhersage") +
  ylab("Beobachtung") +
  # geom_smooth(method = "lm", fill= "lightblue") 
  geom_abline(color = "grey", linetype = 2) +
  annotate("text", x = Inf, y = -Inf, label = paste("R² =", round(Rsquared.test.mM, 3)),
           hjust = 1.18, vjust = -3.5) +
  annotate("text", x = Inf, y = -Inf, label = paste("RMSE =", round(rmse.test.mM, 3)),
           hjust = 1.127, vjust = -1.5) +
  theme_bw()
plot_mM

# Ergebnisse für mR
bands.mR <- bands
predicted.mR <- predicted
testresp.mR <- testresp
Rsquared.training.mR <- Rsquared.training
Rsquared.test.mR <- Rsquared.test
rmse.training.mR <- rmse.training
rmse.test.mR <- rmse
nrmse.training.mR <- nrmse.training
nrmse.test.mR <- nrmse
Ergebnnisse.mR <- cbind(Rsquared.training.mR, Rsquared.test.mR, rmse.training.mR, rmse.test.mR, nrmse.training.mR, nrmse.test.mR)


plot_mR <- ggplot(mapping = aes(x = predicted.mR, y = testresp.mR)) +
  geom_point() +
  xlim(range(testresp.mR)) +
  ylim(range(testresp.mR)) +
  ggtitle("Reaktion (R)") +
  xlab("Vorhersage") +
  ylab("Beobachtung") +
  # geom_smooth(method = "lm", fill= "lightblue") 
  geom_abline(color = "grey", linetype = 2) +
  annotate("text", x = Inf, y = -Inf, label = paste("R² =", round(Rsquared.test.mR, 3)),
           hjust = 1.18, vjust = -3.5) +
  annotate("text", x = Inf, y = -Inf, label = paste("RMSE =", round(rmse.test.mR, 3)),
           hjust = 1.127, vjust = -1.5) +
  theme_bw()
plot_mR

# Ergebnisse für mT
bands.mT <- bands
predicted.mT <- predicted
testresp.mT <- testresp
Rsquared.training.mT <- Rsquared.training
Rsquared.test.mT <- Rsquared.test
rmse.training.mT <- rmse.training
rmse.test.mT <- rmse
nrmse.training.mT <- nrmse.training
nrmse.test.mT <- nrmse
Ergebnnisse.mT <- cbind(Rsquared.training.mT, Rsquared.test.mT, rmse.training.mT, rmse.test.mT, nrmse.training.mT, nrmse.test.mT)

plot_mT <- ggplot(mapping = aes(x = predicted.mT, y = testresp.mT)) +
  geom_point() +
  xlim(range(testresp.mT)) +
  ylim(range(testresp.mT)) +
  ggtitle("Temperatur (T)") +
  xlab("Vorhersage") +
  ylab("Beobachtung") +
  # geom_smooth(method = "lm", fill= "lightblue") 
  geom_abline(color = "grey", linetype = 2) +
  annotate("text", x = Inf, y = -Inf, label = paste("R² =", round(Rsquared.test.mT, 3)),
           hjust = 1.18, vjust = -3.5) +
  annotate("text", x = Inf, y = -Inf, label = paste("RMSE =", round(rmse.test.mT, 3)),
           hjust = 1.127, vjust = -1.5) +
  theme_bw()
plot_mT

library(gridExtra)
PLSR_plots <- grid.arrange(plot_mN, plot_mM, plot_mR, plot_mT, nrow = 2, ncol = 2)
PLSR_plots_eineReihe <- grid.arrange(plot_mN, plot_mM, plot_mR, plot_mT, nrow = 1, ncol = 4)

ggsave(PLSR_plots_eineReihe, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/PLSR_plots.Pre.png",
       width = 40, height = 10, units = "cm")
ggsave(PLSR_plots, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/PLSR_plots.BA.png")

# Visualisierung wichtige Bänder
wavelength <- read.csv("wavelength.csv") %>%
  select(!X)

bands.mN2 <- wavelength %>%
  filter(bands %in% bands.mN)

bands.mM2 <- wavelength %>%
  filter(bands %in% bands.mM)

bands.mR2 <- wavelength %>%
  filter(bands %in% bands.mR)

bands.mT2 <- wavelength %>%
  filter(bands %in% bands.mT)

relevant_wavelengths <- bind_rows(
  mutate(bands.mN2, Indikator = "Stickstoff (N)"),
  mutate(bands.mM2, Indikator = "Feuchte (M)"),
  mutate(bands.mR2, Indikator = "Reaktion (R)"),
  mutate(bands.mT2, Indikator = "Temperatur (T)")
)

relevant_wavelengths <- relevant_wavelengths %>%
  mutate(Indikator = factor(Indikator, levels = c("Temperatur (T)", "Reaktion (R)", "Feuchte (M)", "Stickstoff (N)")))

write.csv(relevant_wavelengths, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/relevant_wavelengths.plsr.csv")

# Plot erstellen
important_wavelength <- ggplot(relevant_wavelengths, aes(x = wavelength, y = Indikator)) +
  geom_rect(xmin = 380, xmax = 430, ymin = -Inf, ymax = Inf, fill = "#FFBBFF", alpha = 0.006) +
  geom_rect(xmin = 430, xmax = 490, ymin = -Inf, ymax = Inf, fill = "cyan", alpha = 0.006) +
  geom_rect(xmin = 490, xmax = 570, ymin = -Inf, ymax = Inf, fill = "green", alpha = 0.006) +
  geom_rect(xmin = 570, xmax = 600, ymin = -Inf, ymax = Inf, fill = "yellow", alpha = 0.006) +
  geom_rect(xmin = 600, xmax = 640, ymin = -Inf, ymax = Inf, fill = "orange", alpha = 0.006) +
  geom_rect(xmin = 640, xmax = 780, ymin = -Inf, ymax = Inf, fill = "red", alpha = 0.006) +
  geom_vline(xintercept = 418.416, linetype = "dashed", color = "gray73") + 
  geom_vline(xintercept = 2445.300, linetype = "dashed", color = "gray73") +
  geom_rect(xmin = 895.789, xmax = 993.338, ymin = -Inf, ymax = Inf, fill = "gray88", alpha = 0.1) + 
  geom_rect(xmin = 1342.82, xmax = 1390.48, ymin = -Inf, ymax = Inf, fill = "gray88", alpha = 0.1) +
  geom_rect(xmin = 1781, xmax = 1967, ymin = -Inf, ymax = Inf, fill = "gray88", alpha = 0.1) +
  geom_errorbar(aes(ymin = Indikator, ymax = Indikator), width = 2, size = 7) +
  labs(x = "Wellenlänge [nm]", y = "Indikatoren") +
  theme_bw()

ggsave(important_wavelength, file = "C:/Users/julia/Documents/Studium/Semester 9/Bachelorarbeit/R Code/OutputR/September2023/important_wl_plsr2.png",
       width = 30, height = 10, units = "cm")
