# ----------------------------------------------------------------
# preprocessing EnMAP & FFH-Wiesen ----
# ----------------------------------------------------------------
# This script is preprocessing the hyperspectral data of EnMap and FFH-Meadow shapefiles

# 1) EnMAP spectral processing
  # 1. cloud masikg
  # 2. mosaic - reconnect all data
  # 3. remove cloudshadows
  # 4. save as TIF

# 2) clip pixelvalues for FFH-Meadow shapefiles
  # 

  # !!!!!!! for now random data is tested !!!!!!!!!!
  # Production Date: 2024 - 09 - 03
  # 22-29
  nr <- 22:29 # add the numbers here

  # EnMAP is hypersectral data
  # records 242 spectral bands across the visible, near-infrared (VNIR) and shortwave infrared (SWIR) ranges:
   # Bands 1–95: VNIR (approx. 420–1000 nm)
   # Bands 96–242: SWIR (approx. 900–2450 nm)
# ----------------------------------------------------------------
# Authors: Neele Haß 
# Project: AI-based Remote Sensing products for Vegetation mapping (AIReSVeg)
# IfGG, 2025
# ----------------------------------------------------------------

# global working directory
setwd("C:/Users/maiim/Documents/25-25SS/Hiwi-IfGG") 

# data paths
enmap_path <-  c("./data/enmap/dims_op_oc_oc-en_701762015_1/ENMAP.HSI.L2A")
shp_path <- file.path("./data/shape/FFH-Maehwiese_polygon.shp") 

# outputdata
out_path <- "./output"

# help functions found in /help-func.R
source("./remoteGit_EnMAP_Hiwi/scripte_neele/help-func.r")

# needed packages ----
needed_packs <- c("terra", "plyr", "dplyr", "isopam")
install_and_load(needed_packs)

options(scipen = 999) # print numbers in fixed (decimal) notation, default: options(scipen = 0)

# ----------------------------------------------------------------
# 1) EnMAP spectral processing ----
# load EnMAP data 
# ----------------------------------------------------------------
enmap_folder <- paste(enmap_path, list.files(enmap_path), sep = "/") # get folder per image
spec_names <- paste0("spec24_", nr) # define nr in the beginning
cloud_names <- paste0("cloud24_", nr) 

# creat list with all raster, list_rast_spec & list_rast_cloud
list_rast_spec <- list()
list_rast_cloud <- list()

for(i in 1:length(nr)){

  # filter for SPECTRAL_IMAGE.TIF 
  enmap_spec <- paste(enmap_folder[i], list.files(enmap_folder[i], pattern = "SPECTRAL_IMAGE.TIF$"), sep = "/" )
  # filter for QL_QUALITY_CLOUD.TIF
  enmap_cloud <- paste(enmap_folder[i], list.files(enmap_folder[i], pattern = "QL_QUALITY_CLOUD.TIF$"), sep = "/" ) 

  # write into list
  list_rast_spec[[i]] <- rast(enmap_spec)
  names(list_rast_spec)[i] <- spec_names[i]

  list_rast_cloud[[i]] <- rast(enmap_cloud)
  names(list_rast_cloud)[i] <- cloud_names[i]
}

# plot(list_rast_cloud$cloud24_22)

# ----------------------------------------------------------------
# Cloud masking ----
# ----------------------------------------------------------------

list_masked <- list()
mask_names <- paste0("enmap24_", nr)

for(i in 1:length(nr)){

  # masking
  masked <- mask(list_rast_spec[[i]], list_rast_cloud[[i]], maskvalues=1)

  # write into list
  list_masked[[i]] <- masked
  names(list_masked)[i] <- mask_names[i]
}

# ----------------------------------------------------------------
# reconnect all data ----
# ----------------------------------------------------------------

# merge all masked raster
enmap.masked <- do.call(terra::merge, unname(list_masked)) # do.call passes named arguments

# change layer names, too long
names(enmap.masked) <- paste0("b", 1:nlyr(enmap.masked))

# plot selection of wavelengths
plot(subset(enmap.masked, c(10, 30, 50))) 

# ----------------------------------------------------------------
# remove could shadows ----
# ----------------------------------------------------------------

# bands of visibel spetrum (780 - 380nm)
RGB <- subset(enmap.masked, 1:64) 
RGBsum <- sum(RGB) # sum up
plot(RGBsum)

# shadow mask
# shadows are marked by lowest value >> search for threshold
shadowmask <- app(RGBsum, function(x) ifelse(x < 28000, NA, x)) 
plot(shadowmask)

# mask with shadowmask
enmap.masked_shadow <- mask(enmap.masked, shadowmask, maskvalues=NA)
plot(subset(enmap.masked_shadow, c(10, 30, 50)))

# ----------------------------------------------------------------
# save as .TIF ----
# ----------------------------------------------------------------
if(!dir.exists(out_path)){ # if needed creat output folder
  dir.create(out_path, recursive = TRUE)
}

# cloud masked
writeRaster(enmap.masked, file.path(out_path, "enmap.masked_24.TIF"), overwrite=TRUE)

# cloud shadow
writeRaster(enmap.masked_shadow, file.path(out_path, "enmap.masked_shadow_24.TIF"), overwrite=TRUE)

# ----------------------------------------------------------------
# 1) 2) clip pixelvalues for FFH-Meadow shapefiles ----
# load .TIF data >> crop meadow polygons
# ----------------------------------------------------------------
# load TIF masked_shadow
enmap.masked_shadow <- rast(file.path(out_path, "enmap.masked_shadow_24.TIF"))
 
mw.poly <- vect(shp_path) %>% crop(enmap.masked_shadow) # crop enmap data by shape file of meadows

plot(mw.poly)

exvals <- extract(enmap.masked_shadow, mw.poly, exact = TRUE) # Pixel values from enmap.masked are extracted that overlap with the polygon, exact=TRUE: also pixels that partially overlap.

# details
str(exvals)
colnames(exvals)
hist(exvals$fraction) 

# Only the extracted values with fraction = 1 fully overlap with the polygon 
# -> discard values < 1
# Then calculate the mean values for each polygon, removing NA values (clouds) beforehand"

exvals2 <- filter(exvals, fraction == 1, !is.na(b1)) %>% # !: reversed, FALSE = missing value, TRUE = value
  select(!fraction) %>% # Spalte Fraction removed
  group_by(ID) %>% # grouping, mean can be calculated
  summarise_all(mean) # mean per polygon

  # Anzahl an Pixeln pro Polygon
npix.poly <- group_by(exvals, ID) %>% 
  summarise(npix.poly = n())
hist(npix.poly$npix.poly)
exvals2 <- left_join(exvals2, npix.poly) %>%
  select(npix.poly, everything())

# Anzahl an verwendeten Pixeln pro Polygon
npix.used <- filter(exvals, fraction == 1, !is.na(b1)) %>% 
  select(!fraction) %>% 
  group_by(ID) %>%
  summarise(npix.used = n())
hist(npix.used$npix.used)
exvals2 <- left_join(exvals2, npix.used) %>%
  select(npix.used, everything())

# Mähwiesennummer aus dem Shapefile Datensatz übernehmen
exvals2 <- mutate(exvals2, MW = mw.poly$MW_NUMMER[exvals2$ID]) %>% 
  select(MW, everything()) %>%
  select(ID, everything())

# checken, ob MW doppelt vorkommen
length(unique(exvals2$MW)) == nrow(exvals2) # nichts doppelt

# ----------------------------------------------------------------
# save as .csv ----
# ----------------------------------------------------------------

write.csv(exvals2, file = file.path(output_folder,"exvals2_23_new.csv"))
