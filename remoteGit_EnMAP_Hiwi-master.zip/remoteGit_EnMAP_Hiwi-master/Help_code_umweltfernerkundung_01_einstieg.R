# 01_einstieg
# In diesem Tutorial geht es um die Grundlagen der Fernerkundung in R.



# Glossar: ----------------------------------------------------------------------

# Landsat 8 / 9 bands

# band     description                                      wavelength    resolution [m]
----------------------------------------------------------------------------------------
  # band 1 : Coastal Aerosol (Operational Land Imager (OLI))  435-451       30
  # band 2 : Blue (OLI)                                       452-512       30
  # band 3 : Green (OLI)                                      533-590       30
  # band 4 : Red (OLI)                                        636-673       30
  # band 5 : Near-Infrared (NIR) (OLI)                        851-879       30
  # band 6 : Short Wavelength Infrared (SWIR) 1(OLI)          1566-1651     30
  # band 7 : SWIR 2 (OLI)                                     2107-2294     30
  # band 10: Thermal Infrared Sensor (TIRS) 1                 10600-11190   30
----------------------------------------------------------------------------------------
  
### Filenames --------------------------------------------------------------------  
# die Benennung von Landsat Files enthält verschiedene Informationen
# wir schauen uns erstmal den Hauptteil an, der bei allen Files gleich ist:
# LC08_L2SP_195026_20230209_20230217_02_T1

# der Name folgt dem Schema
# LXSS_LLLL_PPPRRR_YYYYMMDD_yyyymmdd_CC_TX


  # Identifier   Description
  ----------------------------------------------------------------------------------------
  # L            Landsat
  # X            Sensor of: C = Combined TIRS and OLI Indicates which sensor collected data for this product
  # SS           Landsat satellite (08 for Landsat 8, 09 for Landsat 9)
  # LLLL         Processing level (L2SP, L2SR)
  # PPP          Satellite orbit location in reference to the Worldwide Reference System-2 (WRS-2) path of the product
  # RRR          Satellite orbit location in reference to the WRS-2 row of the product
  # YYYY         Acquisition year of the image
  # MM           Acquisition month of the image
  # DD           Acquisition day of the image
  # yyyy         Processing year of the image
  # mm           Processing month of the image
  # dd           Processing day of the image
  # CC           Collection number (e.g., 02)
  # TX           Collection category: "T1" for Tier 1 (highest quality), "T2" for Tier 2
----------------------------------------------------------------------------------------
  
  
  
# anschließend werden die unterschiedlichen file typen angegeben

# code            file type    
----------------------------------------------------------------------------------------
# MTL             metadata file
# MD5             checksum file,
# SR_B1-7         Surface Reflectance Bands, 
# ST_B10          Surface Temperature Band,
# SR_QA_AEROSOL   Aerosol retrieval per pixel, 
# QA_PIXEL        Level-1 QA Band,
# QA_RADSAT       Radiometric saturation per pixel, 
# ST_QA           Surface Temperature QA,
# ST_TRAD         Thermal band converted to radiance, 
# ST_URAD         Upwelled Radiance,
# ST_DRAD         Downwelled Radiance, 
# ST_ATRAN        Atmospheric Transmittance,
# ST_EMIS         Emissivity estimated from ASTER GED Band 10, 
# ST_EMSD         Emissivity standard deviation, 
# ST_CDIST        Pixel distance to cloud, 
# ANG             angle coefficient file
----------------------------------------------------------------------------------------
  
# genaue informationen zu den files gibt es im 
# Data Format Control Book (DFCB) zu jedem Satellitenprodukt
# Findet ihr auf Ilias
  
  

# Laden der benötigten Pakete. -------------------------------------------------

library(terra)
library(ggplot2)
library(dplyr)
filter(dplyr)
library(sf)
library(mapview)

# Laden externer Funktionen ----------------------------------------------------
# Arbeitsschritte, die man öfter durchführt, kann man als Funktion definieren.
# Ich habe sie in einer zusätzlichen Datei gespeichert.
# Damit hält man das Skript übersichtlich.


source("functions.R")


# terra Funktionen um Datensätze zu erkunden -----------------------------------
# wir schauen uns mal ein Raster File an
# Metadaten anschauen mit der describe Funktion

describe("./data/LC08_L2SP_195026_20230209_20230217_02_T1/LC08_L2SP_195026_20230209_20230217_02_T1_SR_B2.TIF")


# wir laden ein Raster File (band 2, Blauer Spektralkanal)
band2 <- rast("./data/LC08_L2SP_195026_20230209_20230217_02_T1/LC08_L2SP_195026_20230209_20230217_02_T1_SR_B2.TIF")

# und schauen es uns mit der plot Funktion an
plot(band2)

# die Histogramm Funktion erlaubt uns die Verteilung der Pixelwerte darzustellen
hist(band2, breaks=100)  
hist(values(band2))
# wenn man den Wertebereich beschränkt erkennt man mehr
plot(band2,range=c(5000,11000))

# verschiedene Raster Eigenschaften lassen sich auch so nochmal untersuchen
res(band2)
ncol(band2)
nrow(band2)
ncell(band2)
crs(band2)


# einen  Multispektralen Datensatz laden ---------------------------------------

# damit wir nicht jedes mal den gesamten Pfad ausschreiben müssen
# speichern wir uns die Pfade zu den beiden Landsat Produkten als Variable
pfade <- c("./data/LC08_L2SP_195026_20230209_20230217_02_T1/", "./data/LC08_L2SP_195026_20220716_20220726_02_T1/")



# die Funktion list.files gibt alle Files innerhalb des angegebenen Pfades an
list.files(pfade[1])

# wir wollen aber nur Raster Files.
# mit dem Argument pattern kann man die Ergbnisse filtern
list.files(pfade[1], pattern = ".TIF$")


# wir wollen jetzt nur die spektralen Bänder
# also filtern wir noch spezifischer: alle Files, die auf .TIF enden und
# vorher ein B und eine ein bis zweistellige Zahl haben
# das Aufnahmedatum codiert im Filename zeigt uns, dass die Aufnahme aus dem
# Februar 23 stammt
rastList_winter <- list.files(pfade[1], pattern="B[0-9]{1,2}\\.TIF$")

# anschauen
rastList_winter

# mit der rast Funktion laden wir alle gelisteten Raster und kombinieren sie
# zu einem Stapel (vorsicht, bei unterschiedlichen Auflösungen)
winter <- rast(paste0(pfade[1], rastList_winter))

# das gleiche machen wir jetzt für den Sommer
rastList_summer <- list.files(pfade[2], pattern="B[0-9]{1,2}\\.TIF$")
rastList_summer
summer <- rast(paste0(pfade[2], rastList_summer))

# einmal kurz aufräumen im Environment
rm(list = c("band2", "rastList_summer", "rastList_summer"))


# Raster plotten ---------------------------------------------------------------
# und wir schauen uns die geladenen Datensätze an
winter %>% plot()
summer %>% plot()

# auf die einzelnen Raster kann man mit dem Index zugreifen
# wir plotten nochmal alle Bänder einzeln
plot(winter[[1]], main = "Coastal Blue Band", col = gray(0:100 / 100))
plot(winter[[2]], main = "Blue Band", col = gray(0:100 / 100))
plot(winter[[3]], main = "Green Band", col = gray(0:100 / 100))
plot(winter[[4]], main = "Red Band", col = gray(0:100 / 100))
plot(winter[[5]], main = "NIR Band", col = gray(0:100 / 100))
plot(winter[[6]], main = "SWIR Band", col = gray(0:100 / 100))
plot(winter[[7]], main = "SWIR 2 Band", col = gray(0:100 / 100))
plot(winter[[8]], main = "TIR Band", col = gray(0:100 / 100))


# wir plotten die Bänder mit Farben, die ihren spektralen Eigenschaften entsprechen  
plot(winter[[1]], main = "Coastal Blue Band", col = colorRampPalette(c("lightblue", "cyan"))(100))
plot(winter[[2]], main = "Blue Band", col = colorRampPalette(c("deepskyblue", "blue"))(100))
plot(winter[[3]], main = "Green Band", col = colorRampPalette(c("lightgreen", "darkgreen"))(100))
plot(winter[[4]], main = "Red Band", col = colorRampPalette(c("pink", "red"))(100))
plot(winter[[5]], main = "NIR Band", col = colorRampPalette(c("deeppink", "deeppink4"))(100)) # NIR shown in gray tones
plot(winter[[6]], main = "SWIR Band", col = colorRampPalette(c("lavender", "purple3"))(100)) # SWIR in purple tones
plot(winter[[7]], main = "SWIR 2 Band", col = colorRampPalette(c("azure", "purple4"))(100))
plot(winter[[8]], main = "TIR Band", col = colorRampPalette(c("yellow", "darkorange"))(100)) # TIR in orange tones


# die Namen findet man mit der Funktion names heraus
names(winter)

# wir können auch mit dem Name des Bandes darauf zugreifen
plot(winter$LC08_L2SP_195026_20230209_20230217_02_T1_SR_B2)

# das muss aber nicht so sperrig sein, also benennen wir die Bänder um
names(winter) <- c("Coastal Blue","Blue","Green","Red","NIR","SWIR","SWIR 2","TIR")
names(summer) <- c("Coastal Blue","Blue","Green","Red","NIR","SWIR","SWIR 2","TIR")
names(winter)
names(summer)

# um Gruppen von Bändern zu extrahieren, können wir auch den Befehl subset verwenden
subset(winter, 2:4)



# das tidyverse umfasst einige R "Dialekte" die Code potentiell verständlicher machen.
# Die Schreibweise mit Pipes %>%  ist oft übersichtlicher
# der wert vor der Pipe wird in der darauffolgenden Funktion als erstes Argument verwendet
plot(winter[[2]])

# kann man auch so schreiben:
winter[[1]] %>% plot()

winter %>% hist()
winter %>% hist(breaks = 100)



# mit plotRGB kann man 3 Farbkanäle kombinieren
# in "normalem" R - G - B
plotRGB(summer, r = 4, g = 3, b = 2 , stretch = "lin")
plotRGB(summer, r = 4, g = 3, b = 2 , stretch = "hist") # Nah infrarot

# oder in falschfarben NIR - R - G
plotRGB(summer, r = 5, g = 4, b = 3 , stretch = "hist")

# trotz sorgfältiger Auswahl enthält die Szene einige Wolken
# Wolkenmaske ------------------------------------------------------------------

# Information zum atmosphärischen Zustand ist in den Files gespeichert
# die auf QA_PIXEL.TIF enden. Die laden wir jetzt genau wie oben
winter_QA <- list.files(pfade[1], pattern = "_QA_PIXEL.TIF", full.names = T) %>% rast()
summer_QA <- list.files(pfade[2], pattern = "_QA_PIXEL.TIF", full.names = T) %>% rast()

# kurz reinschauen
plot(winter_QA)
plot(summer_QA)
hist(winter_QA)


# Verschiedene Wolkentypen und Schatten sind in den Rasterwerten codiert.
# Zum Decodieren muss man die Werte in Binärschreibweise umformatieren.
# Die Definitionen findet ihr im Data Format Control Book.
# Das ist für uns nicht so wichtig, deshalb habe ich eine Funktion gebaut, die
# das für uns erledigt.

winter_mask <- winter_QA %>% QA_to_Mask()
summer_mask <- summer_QA %>% QA_to_Mask()

# Die Funktion gibt ein Raster aus 1 (Wolke) und 0 (keine Wolke) zurück
# so sieht das aus:
plot(winter_mask)
plot(summer_mask)


# wir können nun die gestapelten Raster maskieren
# dadurch werden alle Wolkenbedeckten Bereiche mit NA gefüllt
winter_nocl <- mask(winter, winter_mask, maskvalue = 1) 
summer_nocl <- mask(summer, summer_mask, maskvalue = 1)

# kurzer vorher/nachher Check:
par(mfrow = c(1,2))
summer      %>% plotRGB(r = 4, g = 3, b = 2 , stretch = "hist")
summer_nocl %>% plotRGB(r = 4, g = 3, b = 2 , stretch = "hist")
par(mfrow = c(1,1))


# Datensatz zuschneiden --------------------------------------------------------
# die Datensätze sind groß, insbesondere, wenn man große gebiete oder viele Zeitschritte
# betrachten möchte. deshalb macht es oft Sinn die Szenen handlich zuzuschneiden
# wir laden uns dazu die Landkreise als Shapefile
kreise <- read_sf("./data/BW_kreise/AX_Gebiet_Kreis.shp")

# was steckt drin?
kreise 

# wir brauchen nur die Gebiete in und um Karlsruhe
LK <- subset(kreise, Name == "Karlsruhe")


# hier nochmal den Sommer plotten
summer_nocl %>% plotRGB(r=4, g=3, b=2 , stretch="hist")

## jetzt können wir die Landkreise darüberlegen um uns zu orientieren
st_geometry(kreise) %>% plot(add=TRUE, fill=FALSE)
st_geometry(LK) %>% plot(add =TRUE, border = "red")


# jetzt speichern wir uns die Bounding-Box
# aber nur vom Stadtgebiet
extent <- subset(kreise, Schlüssel == "08212") %>% st_bbox()


# diesen Extent können wir jetzt verwenden, um unseren Datensatz zuzuschneiden
# wir speichern den fertig vorprozessierten Datensatz gleichzeitig im Output-Ordner
winter_ka <- crop(winter_nocl, extent, snap="out", filename = "./output/winter.tif", overwrite = TRUE)
summer_ka <- crop(summer_nocl, extent, snap="out", filename = "./output/summer.tif", overwrite = TRUE)


# anschauen
par(mfrow=c(1,2))
plotRGB(winter_ka, r=4, g=3, b=2, stretch="hist")
plotRGB(summer_ka, r=4, g=3, b=2, stretch="hist")
plotRGB(winter_ka, r=5, g=4, b=3, stretch="hist")
plotRGB(summer_ka, r=5, g=4, b=3, stretch="hist")
par(mfrow=c(1,1))



# Raster Algebra ---------------------------------------------------------------
# als erstes können wir uns anschauen, wie sich die thermalen infrarotbänder
# zwischen Sommer und Winter unterscheiden

# wir subtrahieren einfach die beiden Raster
tir_diff <- summer_ka$TIR - winter_ka$TIR
plot(tir_diff)



# berechnen wir den NDVI
# ndvi = (NIR - Red) / (NIR + Red)
# landsat 8/9 baender 4: red, 5: NIR


ndvi_winter <- (winter_ka$NIR - winter_ka$Red) / (winter_ka$NIR + winter_ka$Red)
plot(ndvi_winter)

# bevor wir das nochmal ausschreiben implementieren wir es lieber als Funktion
ndvi <- function(red, NIR){
  res <- (NIR - red) / (NIR + red)
  return(res) 
}
ndvi_sim <- function(data){
  red <- data$Red
  NIR <- data$NIR
  
  res <- (NIR - red) / (NIR + red)
  return(res) 
}

# jetzt können wir die Funktion direkt anwenden
ndvi_summer <- ndvi(summer_ka$Red, summer_ka$NIR)
ndvi_summer_sim <- ndvi_sim(summer_ka)
plot(ndvi_summer_sim)

# stacken
ndvis <- c(ndvi_winter,ndvi_summer)
names(ndvis) <- c("winter", "summer")
plot(ndvis)


# um einheitliche Skalen und mehr Kontrolle zu haben laden wir noch zwei Pakete
library(rasterVis)
library(RColorBrewer)
library(lattice)

levelplot(ndvis)

#noch ein besseres Farbschema auswählen
cols <- colorRampPalette(brewer.pal(9,"YlGn"))
levelplot(ndvis, col.regions=cols)


# und zum Schluss die Veränderung des NDVI zwischen Winter und Sommer
diff <- ndvis$summer - ndvis$winter

plot(diff)
st_geometry(LK) %>% plot(add =TRUE, border = "red")

# speichern ndvi_winter und summer
output_path_win <- "./output/ndvi_winter.tif"
writeRaster(ndvi_winter, filename = output_path_win, overwrite = TRUE)

output_path_sum <- "./output/ndvi_summer.tif"
writeRaster(ndvi_summer, filename = output_path_sum, overwrite = TRUE)

## Aufgabe 1 -------------------------------------------------------------------
# Kleine Aufgabe für Euch: 
# besorgt euch die Stadtteilgrenzen von Karlsruhe und schaut in welchen
# Stadtteilen sich die NDVI Werte von Sommer und Winter am meisten 
# unterscheiden. überlegt, warum.
# Abgabe: min, max, barplot, ~5 Zeilen Text und code
library(rasterVis)
library(RColorBrewer)
library(lattice)
library(terra)

# 1.1 Winter & Summer NDVI einlesen (winter_ka & summer_ka in output)
path <-"./output/"
winter_ka <- rast(paste(path, "winter.tif", sep = ""))
summer_ka <- rast(paste(path, "summer.tif", sep = ""))

ndvi_winter <- rast(paste(path, "ndvi_winter.tif", sep = ""))
ndvi_summer <- rast(paste(path, "ndvi_summer.tif", sep = ""))

# 1.1 Stadtteilgrenzen von KA
# https://transparenz.karlsruhe.de/dataset/stadtteile/resource/b11bc64d-c511-4fec-bc99-7333989ec673

KA_stadtteile <- read_sf("./data/KA_stadtteile/Stadtteile 2020-04.shp")
View(KA_stadtteile)

# 1.2 NDVI und dif
# stacken
ndvis <- c(ndvi_winter,ndvi_summer)
names(ndvis) <- c("winter", "summer")
# plot
cols <- colorRampPalette(brewer.pal(9,"YlGn"))
levelplot(ndvis, col.regions=cols)


# NDVI dif 
dif <- ndvis$summer - ndvis$winter
names(dif) <- "NDVI_dif"

plot(dif, main = "NDVI dif Summer - Winter (Karlsruhe)")
st_geometry(KA_stadtteile) %>% plot(add =TRUE, border = "red")

# 1.2 welcher Stadtteil hat größte dif NDVI Sommer/Winter
dif_means <- terra::extract(dif, KA_stadtteile, fun = mean)
# Coordinate Ref Sysy (CRS) prüfen
print(crs(dif))          # CRS projec. --> "WGS 84 / UTM zone 32N\"
print(st_crs(KA_stadtteile)) # CRS projec. --> "ETRS89 / UTM zone 32N"

# anpassen des CRS von Stadtteilen (chatGPT)
if (!st_crs(KA_stadtteile)$proj4string == crs(dif, proj = TRUE)) {
  KA_stadtteile <- st_transform(KA_stadtteile, crs(dif, proj = TRUE))
}
# nochmal ausführen 
dif_means <- terra::extract(dif, KA_stadtteile, fun = mean, na.rm = TRUE)
View(dif_means)
# neue spalte
KA_stadtteile$mean_NDVI_Diff <- dif_means$NDVI_dif
View(KA_stadtteile)

# barplot
district_names <- KA_stadtteile$`Stt-Name`
ndvi_diff_values <- KA_stadtteile$mean_NDVI_Diff

# sortieren 
sort_ind <- order(ndvi_diff_values)  # Sortiere aufsteigend
sort_ndvi_diff <- ndvi_diff_values[sort_ind]
sorted_stadtteile <- district_names[sort_ind]
# Basic barplot
barplot(sort_ndvi_diff,
        names.arg = sorted_stadtteile,
        las = 2, # hochkannt
        col = "light green",
        main = "NDVI dif Summer - Winter (Karlsruhe)",
        xlab = "",
        ylab = "NDVI dif")

# min and max
max_diff <- KA_stadtteile[which.max(KA_stadtteile$mean_NDVI_Diff), ]
min_diff <- KA_stadtteile[which.min(KA_stadtteile$mean_NDVI_Diff), ]

print(paste("der Stadtteil mit min NDVI dif ist:", min_diff$`Stt-Name`, 
            ", NDVI Dif = ", round(min_diff$mean_NDVI_Diff, 3)))
print(paste("der Stadtteil mit max NDVI dif ist:", max_diff$`Stt-Name`, 
            ", NDVI Dif = ", round(max_diff$mean_NDVI_Diff , 3)))
# markiere Stadtteile
plot(dif, main = "NDVI dif Summer - Winter (Karlsruhe)")
st_geometry(KA_stadtteile) %>% plot(add =TRUE, border = "black")
plot(st_geometry(max_diff), add = TRUE, border = "blue", lwd = 2)
plot(st_geometry(min_diff), add = TRUE, border = "yellow", lwd = 2)

# 1.3 warum?
# "der Stadtteil mit min NDVI dif ist: Palmbach , NDVI Dif =  0.052"
# "der Stadtteil mit max NDVI dif ist: Weiherfeld-Dammerstock , NDVI Dif =  0.184"

# ergebniss hinterfragen ? - ist sortierung richtig - zuOrdnung von mean NDVI zu stadtteilen?


# Aufgabe 2 --------------------------------------------------------------------
# Berechnet den EVI (Enhanced Vegetation Index) und vergleicht
# die Ergebnisse zwischen Winter und Sommer. Wie unterscheiden sich NDVI und EVI?
# Abgabe: plot, ~5 Zeilen Text und code

# Abgabe als pdf (probiert gerne Rmarkdown aka Quarto) 