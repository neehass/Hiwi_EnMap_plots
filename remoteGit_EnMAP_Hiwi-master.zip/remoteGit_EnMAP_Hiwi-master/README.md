# Hiwi IfGG, 2025
# AI-based Remote Sensing products for Vegetation mapping (AIReSVeg)
## Ziel 
Mähwiesen Klassifikation mithilfe von Fernerkundung (Hyperspektraldaten)
Erhaltungszustand: abc FFH
- Managmenthandbuch - FFH gebiete BW

### Vorhandene Arbeiten: 
- BA Julia (R_Code)
- Forschungsprojekt Luise (text)
- Projekt Felix (R_Code)

# to-dos
- Data durchschauen

- BA & Forschungsprojekt lesen 
- EnMAP BaWü data runterladen + NeuSeeland (für Schmidtlein)

- GitHub Remote Repo erstellen für Skripte
- in Skripte einarbeiten

------------------------------
login data nomachine:
	username: Rapidito 
	IP: 129.13.75.73
	
	username:ifgg1
	key: daucus1!

Workstation
	username: Rapidito 
	key: daucus1!

------------------------------